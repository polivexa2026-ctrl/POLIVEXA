# POLIVEXA — polivexa.com

A marketing site for POLIVEXA's dual-track DPDP Act 2023 compliance and enterprise IT consulting.

**Stack:** Next.js 14 (App Router) · TypeScript · Tailwind CSS · shadcn/ui (Radix) · Framer Motion · Lucide React · Plus Jakarta Sans (self-hosted via @fontsource, no Google Fonts request at runtime).

## Run locally
```bash
npm install
npm run dev        # http://localhost:3000
npm run build && npm start
```
Static hosting (S3/CloudFront, Netlify, etc.): `NEXT_OUTPUT=export npm run build` → deploy `/out`.
Vercel: import the repo, no config needed.

## Lead capture
All forms (the modal, the inline contact form and the scorecard's "Download Gap Assessment") post JSON to
`NEXT_PUBLIC_LEAD_ENDPOINT` if you set it (HubSpot/Zoho webhook, Formspree, your own API, etc.).
Payload: `name, email, company, industry, cloud, stage, intent, context, consentedAt, source`.
If it's not set, the forms simulate a successful submit so you can preview them.
Free-mail domains (gmail, yahoo…) are rejected so only work emails get through.

## Structure
```
app/                layout (SEO metadata, JSON-LD), page, /about, /privacy, /terms, icon.svg
components/ui/      shadcn/ui primitives: button, badge, input, label, accordion, tabs, dialog, select
components/lead/    LeadForm + LeadModalProvider (useLeadModal().open({ intent }))
components/sections header, hero, dashboard-mock, why-polivexa (bento), services (tabs),
                    readiness-calculator, framework, trust, faq, contact, footer
components/about/    about-hero (mission/vision/values bento), leadership, governance, about-cta
lib/team.ts         leadership roster: names, roles, credentials, bios, photo paths, social links
lib/site.ts         contact emails, domain, services-tab event helper
```
Design tokens live in `tailwind.config.ts`: `navy` #0A192F / #0B132B, `accent` #00D2B4, `accent.emerald` #10B981.

## About page: photos & profiles
Put portraits in `public/images/team/` (4:5 JPG, at least 800×1000). The filenames are listed in that folder's README
(e.g. `megha-kumari.jpg`, `abhishek-bharti.jpg`). The build checks which files exist, so each card shows the photo
if there is one and an initials placeholder if there isn't. Rebuild after adding photos.
Add LinkedIn / X / email per person in `lib/team.ts`. Missing links show as muted icons, never as dead links.

## Before launch: replace these placeholders
- `lib/site.ts`: phone number, and confirm the email addresses (hello@, grievance@, dpo@).
- `components/sections/trust.tsx`: the **engagement snapshots are illustrative** and labelled that way on the page.
  Swap in real case studies your clients have approved (and drop the "Illustrative" badge) before you add any client names or quotes.
- Footer social URLs.
- `/privacy` and `/terms` are templates (a banner on each page says so). Have counsel review them.
- FAQ and penalty figures follow the DPDP Act 2023 Schedule and the phased DPDP Rules 2025. Re-check the dates against the Gazette before you publish.
