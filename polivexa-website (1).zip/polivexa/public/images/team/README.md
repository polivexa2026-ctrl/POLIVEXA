Add leadership portraits here (4:5 portrait, ≥800×1000 JPG). Filenames must match lib/team.ts:

- abhishek-bharti.jpg
- megha-kumari.jpg
- ujjawal-raj.jpg
- ajay-kumar-paswan.jpg
- sarita-singh.jpg

Cards show an initials monogram until the file exists. Rebuild after adding photos.
