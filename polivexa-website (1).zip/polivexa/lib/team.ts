/**
 * Leadership roster for /about.
 *
 * PHOTOS: drop portraits into /public/images/team/ using the filenames below
 * (JPG, ideally 800×1000 or larger, 4:5). Until a file exists the card shows an
 * initials monogram, so the page never renders a broken image.
 *
 * SOCIAL LINKS: fill in `linkedin` / `x` when ready. Empty values render as a
 * muted, non-clickable icon so no dead links ship.
 */
export type Accolade = { label: string; kind: "award" | "book" | "degree" | "experience" | "policy" };

export type TeamMember = {
  slug: string;
  name: string;
  role: string;
  credential: Accolade[];
  bio: string;
  image: string; // path under /public
  linkedin?: string;
  x?: string;
  email?: string;
  featured?: boolean;
};

export const TEAM: TeamMember[] = [
  {
    slug: "abhishek-bharti",
    name: "Abhishek Bharti",
    role: "Chief Technology Officer (CTO)",
    featured: true,
    credential: [
      { label: "Times Men of the Year (2019)", kind: "award" },
      { label: "Young Achiever Award (2025, News18 Group)", kind: "award" },
      { label: "Published Author", kind: "book" },
    ],
    bio: "Visionary technology architect leading Polivexa’s technical and privacy engineering verticals. Recognized as Times Men of the Year (2019) and honored with the Young Achiever Award (2025) by News18 Group. A published author and systems strategist orchestrating data protection workflows, AI-driven governance, and secure cloud ecosystems.",
    image: "/images/team/abhishek-bharti.jpg",
    linkedin: "",
    x: "",
    email: "",
  },
  {
    slug: "megha-kumari",
    name: "Megha Kumari",
    role: "Director",
    credential: [{ label: "Post Graduate", kind: "degree" }],
    bio: "Drives strategic growth, operational compliance, and organizational governance at Polivexa, ensuring seamless execution across enterprise advisory initiatives.",
    image: "/images/team/megha-kumari.jpg",
    linkedin: "",
    x: "",
    email: "",
  },
  {
    slug: "ujjawal-raj",
    name: "Ujjawal Raj",
    role: "Director",
    credential: [{ label: "B.Tech", kind: "degree" }],
    bio: "Oversees technical delivery and infrastructure alignment, specializing in translating complex regulatory frameworks into robust, scalable IT solutions.",
    image: "/images/team/ujjawal-raj.jpg",
    linkedin: "",
    x: "",
    email: "",
  },
  {
    slug: "ajay-kumar-paswan",
    name: "Ajay Kumar Paswan",
    role: "Director",
    credential: [{ label: "14+ Years in Media & Consulting", kind: "experience" }],
    bio: "Veteran enterprise advisor bringing over 14 years of rich industry leadership across media, public relations, and strategic consulting to govern external stakeholder engagement and compliance trust.",
    image: "/images/team/ajay-kumar-paswan.jpg",
    linkedin: "",
    x: "",
    email: "",
  },
  {
    slug: "sarita-singh",
    name: "Sarita Singh",
    role: "Director",
    credential: [{ label: "Former MLA, New Delhi | Public Policy Leader", kind: "policy" }],
    bio: "Renowned public figure and former Member of the Legislative Assembly (Delhi), offering unparalleled expertise in public advocacy, policy strategy, citizen-first governance, and regulatory interface.",
    image: "/images/team/sarita-singh.jpg",
    linkedin: "",
    x: "",
    email: "",
  },
];
