export const site = {
  name: "POLIVEXA",
  domain: "polivexa.com",
  url: "https://polivexa.com",
  email: "hello@polivexa.com",
  grievanceEmail: "grievance@polivexa.com",
  dpoEmail: "dpo@polivexa.com",
  phone: "+91 00000 00000",
};

/** Dispatch to switch the Services tab from anywhere (nav dropdown, footer). */
export const SERVICES_TAB_EVENT = "polivexa:services-tab";
export type ServicesTab = "dpdp" | "it";

export function goToServices(tab: ServicesTab) {
  if (typeof window === "undefined") return;
  const el = document.getElementById("services");
  if (!el) {
    // On another page (e.g. /about): go home and open the requested tab there.
    window.location.href = `/?tab=${tab}#services`;
    return;
  }
  window.dispatchEvent(new CustomEvent<ServicesTab>(SERVICES_TAB_EVENT, { detail: tab }));
  el.scrollIntoView({ behavior: "smooth" });
}
