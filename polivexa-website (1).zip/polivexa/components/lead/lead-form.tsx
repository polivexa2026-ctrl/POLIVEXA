"use client";
import * as React from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, CalendarCheck, CheckCircle2, Loader2, Lock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { site } from "@/lib/site";

export const INDUSTRIES = [
  "FinTech / BFSI",
  "E-Commerce & Retail",
  "SaaS / Technology",
  "Healthcare & Pharma",
  "EdTech",
  "Telecom & Media",
  "Manufacturing",
  "Government / PSU",
  "Other",
];

export const CLOUD_PLATFORMS = ["AWS", "Microsoft Azure", "Google Cloud", "Multi-cloud", "Hybrid / On-premise", "Not sure"];

export const PREPAREDNESS_STAGES = [
  "Not started — exploring obligations",
  "Awareness — initial gap review done",
  "In progress — remediation underway",
  "Advanced — validating & audit-ready",
];

export type LeadIntent = "consultation" | "audit" | "gap-assessment" | "scorecard";

export const INTENT_COPY: Record<LeadIntent, { title: string; description: string; cta: string }> = {
  consultation: {
    title: "Book a consultation",
    description: "Talk to a DPDP and enterprise IT specialist. We'll reply within one business day.",
    cta: "Book consultation",
  },
  audit: {
    title: "Schedule a compliance audit",
    description: "A scoped DPDP Act 2023 audit across your legal, process and technology layers.",
    cta: "Schedule audit",
  },
  "gap-assessment": {
    title: "Get your comprehensive gap assessment",
    description: "We'll send a detailed, clause-mapped DPDP gap assessment based on your scorecard answers.",
    cta: "Send my gap assessment",
  },
  scorecard: {
    title: "DPDP Readiness Scorecard",
    description: "Receive the full scorecard with section-by-section readiness benchmarks for your industry.",
    cta: "Get my scorecard",
  },
};

type Fields = {
  name: string;
  email: string;
  company: string;
  industry: string;
  cloud: string;
  stage: string;
};

const FREE_MAIL = /@(gmail|yahoo|hotmail|outlook|live|icloud|aol|proton(mail)?|rediffmail|yandex)\./i;

function validate(f: Fields) {
  const e: Partial<Record<keyof Fields, string>> = {};
  if (f.name.trim().length < 2) e.name = "Please enter your full name.";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(f.email)) e.email = "Enter a valid email address.";
  else if (FREE_MAIL.test(f.email)) e.email = "Please use your work email.";
  if (f.company.trim().length < 2) e.company = "Company name is required.";
  if (!f.industry) e.industry = "Select your industry.";
  if (!f.cloud) e.cloud = "Select a cloud platform.";
  if (!f.stage) e.stage = "Select your preparedness stage.";
  return e;
}

export function LeadForm({
  intent = "consultation",
  defaultStage,
  context,
  dark = false,
  onSuccess,
}: {
  intent?: LeadIntent;
  defaultStage?: string;
  /** Extra metadata sent with the lead, e.g. readiness scorecard answers. */
  context?: Record<string, unknown>;
  dark?: boolean;
  onSuccess?: () => void;
}) {
  const [fields, setFields] = React.useState<Fields>({
    name: "",
    email: "",
    company: "",
    industry: "",
    cloud: "",
    stage: defaultStage ?? "",
  });
  const [errors, setErrors] = React.useState<Partial<Record<keyof Fields, string>>>({});
  const [consent, setConsent] = React.useState(false);
  const [consentError, setConsentError] = React.useState(false);
  const [status, setStatus] = React.useState<"idle" | "loading" | "done">("idle");

  const set = (k: keyof Fields) => (v: string) => {
    setFields((p) => ({ ...p, [k]: v }));
    if (errors[k]) setErrors((p) => ({ ...p, [k]: undefined }));
  };

  async function submit(ev: React.FormEvent) {
    ev.preventDefault();
    const e = validate(fields);
    setErrors(e);
    setConsentError(!consent);
    if (Object.keys(e).length || !consent) return;

    setStatus("loading");
    const payload = { ...fields, intent, context, consentedAt: new Date().toISOString(), source: site.domain };
    const endpoint = process.env.NEXT_PUBLIC_LEAD_ENDPOINT;
    try {
      if (endpoint) {
        await fetch(endpoint, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      } else {
        // No endpoint configured — simulate latency in development/preview.
        await new Promise((r) => setTimeout(r, 900));
      }
    } finally {
      setStatus("done");
      onSuccess?.();
    }
  }

  const copy = INTENT_COPY[intent];
  const labelCls = dark ? "text-slate-200" : undefined;
  const errCls = "mt-1.5 text-xs font-medium text-rose-500";

  return (
    <AnimatePresence mode="wait" initial={false}>
      {status === "done" ? (
        <motion.div
          key="done"
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          className="flex flex-col items-center py-8 text-center"
        >
          <span className="relative flex h-16 w-16 items-center justify-center">
            <span className="absolute inset-0 animate-pulse-ring rounded-full bg-accent/40" />
            <CheckCircle2 className="relative h-16 w-16 text-accent" strokeWidth={1.6} />
          </span>
          <h3 className={cn("mt-5 text-xl font-bold", dark ? "text-white" : "text-navy")}>
            Thank you, {fields.name.split(" ")[0]}.
          </h3>
          <p className={cn("mt-2 max-w-sm text-sm", dark ? "text-slate-300" : "text-slate-600")}>
            A Polivexa specialist will reach out to <strong>{fields.email}</strong> within one business day with next steps
            {intent === "gap-assessment" || intent === "scorecard" ? " and your assessment" : ""}.
          </p>
        </motion.div>
      ) : (
        <motion.form key="form" onSubmit={submit} noValidate className="grid gap-4 sm:grid-cols-2" exit={{ opacity: 0 }}>
          <div>
            <Label htmlFor={`${intent}-name`} className={labelCls}>Full name</Label>
            <Input
              id={`${intent}-name`}
              className="mt-2"
              autoComplete="name"
              placeholder="Priya Sharma"
              value={fields.name}
              aria-invalid={!!errors.name}
              onChange={(e) => set("name")(e.target.value)}
            />
            {errors.name && <p className={errCls}>{errors.name}</p>}
          </div>
          <div>
            <Label htmlFor={`${intent}-email`} className={labelCls}>Work email</Label>
            <Input
              id={`${intent}-email`}
              className="mt-2"
              type="email"
              autoComplete="email"
              placeholder="priya@company.com"
              value={fields.email}
              aria-invalid={!!errors.email}
              onChange={(e) => set("email")(e.target.value)}
            />
            {errors.email && <p className={errCls}>{errors.email}</p>}
          </div>
          <div className="sm:col-span-2">
            <Label htmlFor={`${intent}-company`} className={labelCls}>Company name</Label>
            <Input
              id={`${intent}-company`}
              className="mt-2"
              autoComplete="organization"
              placeholder="Acme Technologies Pvt. Ltd."
              value={fields.company}
              aria-invalid={!!errors.company}
              onChange={(e) => set("company")(e.target.value)}
            />
            {errors.company && <p className={errCls}>{errors.company}</p>}
          </div>
          <div>
            <Label className={labelCls}>Industry</Label>
            <Select value={fields.industry} onValueChange={set("industry")}>
              <SelectTrigger className="mt-2" aria-invalid={!!errors.industry} aria-label="Industry">
                <SelectValue placeholder="Select industry" />
              </SelectTrigger>
              <SelectContent>
                {INDUSTRIES.map((i) => (
                  <SelectItem key={i} value={i}>{i}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.industry && <p className={errCls}>{errors.industry}</p>}
          </div>
          <div>
            <Label className={labelCls}>Cloud platform</Label>
            <Select value={fields.cloud} onValueChange={set("cloud")}>
              <SelectTrigger className="mt-2" aria-invalid={!!errors.cloud} aria-label="Cloud platform">
                <SelectValue placeholder="Select platform" />
              </SelectTrigger>
              <SelectContent>
                {CLOUD_PLATFORMS.map((i) => (
                  <SelectItem key={i} value={i}>{i}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.cloud && <p className={errCls}>{errors.cloud}</p>}
          </div>
          <div className="sm:col-span-2">
            <Label className={labelCls}>DPDP preparedness stage</Label>
            <Select value={fields.stage} onValueChange={set("stage")}>
              <SelectTrigger className="mt-2" aria-invalid={!!errors.stage} aria-label="DPDP preparedness stage">
                <SelectValue placeholder="Where are you today?" />
              </SelectTrigger>
              <SelectContent>
                {PREPAREDNESS_STAGES.map((i) => (
                  <SelectItem key={i} value={i}>{i}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {errors.stage && <p className={errCls}>{errors.stage}</p>}
          </div>

          {/* DPDP-style specific, informed consent for our own lead capture */}
          <label className="flex cursor-pointer items-start gap-3 sm:col-span-2">
            <input
              type="checkbox"
              checked={consent}
              onChange={(e) => {
                setConsent(e.target.checked);
                if (e.target.checked) setConsentError(false);
              }}
              className="mt-0.5 h-4 w-4 shrink-0 cursor-pointer rounded border-slate-300 accent-[#00D2B4]"
            />
            <span className={cn("text-xs leading-relaxed", dark ? "text-slate-400" : "text-slate-500")}>
              I consent to POLIVEXA processing the details above solely to respond to this request, as described in the{" "}
              <a href="/privacy" className="font-semibold text-[#00A58D] underline-offset-2 hover:underline">Privacy Notice</a>.
              I can withdraw consent anytime by writing to {site.dpoEmail}.
            </span>
          </label>
          {consentError && <p className={cn(errCls, "-mt-2 sm:col-span-2")}>Consent is required to process your request.</p>}

          <div className="flex flex-col gap-3 sm:col-span-2 sm:flex-row sm:items-center sm:justify-between">
            <p className={cn("inline-flex items-center gap-1.5 text-xs", dark ? "text-slate-400" : "text-slate-500")}>
              <Lock className="h-3.5 w-3.5 text-accent" /> Encrypted in transit. Never sold or shared.
            </p>
            <Button type="submit" size="lg" disabled={status === "loading"} className="w-full sm:w-auto">
              {status === "loading" ? (
                <Loader2 className="animate-spin" />
              ) : intent === "consultation" ? (
                <CalendarCheck />
              ) : null}
              {copy.cta}
              {status !== "loading" && <ArrowRight className="transition-transform group-hover:translate-x-0.5" />}
            </Button>
          </div>
        </motion.form>
      )}
    </AnimatePresence>
  );
}
