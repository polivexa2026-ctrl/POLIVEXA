"use client";
import * as React from "react";
import { ShieldCheck } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { INTENT_COPY, LeadForm, type LeadIntent } from "@/components/lead/lead-form";

type OpenOptions = { intent?: LeadIntent; defaultStage?: string; context?: Record<string, unknown> };

const LeadModalContext = React.createContext<{ open: (o?: OpenOptions) => void } | null>(null);

export function useLeadModal() {
  const ctx = React.useContext(LeadModalContext);
  if (!ctx) throw new Error("useLeadModal must be used within LeadModalProvider");
  return ctx;
}

export function LeadModalProvider({ children }: { children: React.ReactNode }) {
  const [isOpen, setOpen] = React.useState(false);
  const [opts, setOpts] = React.useState<OpenOptions>({});
  // Remount the form on each open so state resets.
  const [key, setKey] = React.useState(0);

  const open = React.useCallback((o: OpenOptions = {}) => {
    setOpts(o);
    setKey((k) => k + 1);
    setOpen(true);
  }, []);

  const intent = opts.intent ?? "consultation";
  const copy = INTENT_COPY[intent];

  return (
    <LeadModalContext.Provider value={{ open }}>
      {children}
      <Dialog open={isOpen} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <span className="mb-2 inline-flex h-11 w-11 items-center justify-center rounded-xl bg-accent/10 text-[#00A58D] ring-1 ring-accent/30">
              <ShieldCheck className="h-5 w-5" />
            </span>
            <DialogTitle>{copy.title}</DialogTitle>
            <DialogDescription>{copy.description}</DialogDescription>
          </DialogHeader>
          <div className="mt-2">
            <LeadForm key={key} intent={intent} defaultStage={opts.defaultStage} context={opts.context} />
          </div>
        </DialogContent>
      </Dialog>
    </LeadModalContext.Provider>
  );
}
