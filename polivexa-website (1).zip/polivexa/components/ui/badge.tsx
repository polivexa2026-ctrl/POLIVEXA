import * as React from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-semibold transition-colors",
  {
    variants: {
      variant: {
        default: "border-accent/30 bg-accent/10 text-[#00937F]",
        dark: "border-accent/30 bg-accent/10 text-accent",
        secondary: "border-slate-200 bg-slate-100 text-slate-700",
        outline: "border-slate-300 text-slate-700",
        warning: "border-amber-300/40 bg-amber-400/10 text-amber-500",
        danger: "border-rose-400/30 bg-rose-500/10 text-rose-400",
      },
    },
    defaultVariants: { variant: "default" },
  }
);

export interface BadgeProps extends React.HTMLAttributes<HTMLDivElement>, VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return <div className={cn(badgeVariants({ variant }), className)} {...props} />;
}

export { Badge, badgeVariants };
