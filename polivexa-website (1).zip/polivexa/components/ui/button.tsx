import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "group inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-semibold transition-all duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 active:scale-[0.98] [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default:
          "bg-accent text-navy shadow-[0_8px_24px_-8px_rgba(0,210,180,0.6)] hover:bg-[#1BE3C6] hover:shadow-[0_10px_30px_-8px_rgba(0,210,180,0.75)]",
        navy: "bg-navy text-white hover:bg-navy-700 shadow-sm",
        outline:
          "border border-slate-300 bg-white text-navy hover:border-accent hover:text-navy hover:bg-accent/5",
        "outline-dark":
          "border border-white/20 bg-white/5 text-white backdrop-blur hover:border-accent/70 hover:bg-accent/10",
        ghost: "text-slate-600 hover:bg-slate-100 hover:text-navy",
        "ghost-dark": "text-slate-300 hover:bg-white/5 hover:text-white",
        link: "text-accent underline-offset-4 hover:underline",
      },
      size: {
        default: "h-10 px-4 py-2",
        sm: "h-9 px-3 text-[13px]",
        lg: "h-12 px-6 text-[15px]",
        icon: "h-10 w-10",
      },
    },
    defaultVariants: { variant: "default", size: "default" },
  }
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />;
  }
);
Button.displayName = "Button";

export { Button, buttonVariants };
