"use client";
import { motion } from "framer-motion";
import { ArrowRight, BadgeCheck, CalendarCheck, Gauge, IndianRupee, Layers, ShieldCheck, UserCheck } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLeadModal } from "@/components/lead/lead-modal";
import { DashboardMock } from "@/components/sections/dashboard-mock";

const TICKER = [
  { icon: IndianRupee, text: "Up to ₹250 Cr Penalty Protection" },
  { icon: UserCheck, text: "100% Data Principal Rights Workflow" },
  { icon: Layers, text: "ISO 27001 & DPDP Integrated" },
  { icon: ShieldCheck, text: "72-hr Breach Notification Framework" },
  { icon: BadgeCheck, text: "Notices in 22 Scheduled Languages" },
];

export function Hero() {
  const { open } = useLeadModal();

  return (
    <section id="top" className="relative isolate overflow-hidden bg-navy-900 pt-[72px]">
      {/* Background: grid + gradient orbs */}
      <div className="absolute inset-0 -z-10 bg-grid-light bg-[size:56px_56px] [mask-image:radial-gradient(ellipse_80%_60%_at_50%_30%,black,transparent)]" />
      <div className="absolute -top-40 left-1/2 -z-10 h-[520px] w-[900px] -translate-x-1/2 rounded-full bg-accent/15 blur-[120px]" />
      <div className="absolute -right-40 top-40 -z-10 h-[420px] w-[420px] rounded-full bg-emerald-500/10 blur-[100px]" />

      <div className="container grid items-center gap-14 pb-16 pt-14 sm:pt-20 lg:grid-cols-[1.05fr_1fr] lg:gap-10 lg:pb-24 lg:pt-24">
        <div className="max-w-2xl">
          <motion.a
            href="#framework"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="group inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 py-1 pl-1 pr-3 text-xs font-medium text-slate-300 backdrop-blur transition hover:border-accent/40"
          >
            <span className="whitespace-nowrap rounded-full bg-accent px-2 py-0.5 text-[11px] font-bold text-navy">DPDP Rules 2025</span>
            <span className="sm:hidden">Deadlines are phasing in</span>
            <span className="hidden sm:inline">Phased compliance deadlines are live</span>
            <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
          </motion.a>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.08, ease: [0.22, 1, 0.36, 1] }}
            className="mt-6 text-balance text-[34px] font-extrabold leading-[1.08] tracking-[-0.012em] text-white sm:text-5xl lg:text-[56px]"
          >
            End-to-End <span className="text-gradient">DPDP Act 2023</span> Compliance &amp; Enterprise IT Transformation.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.16, ease: [0.22, 1, 0.36, 1] }}
            className="mt-6 max-w-xl text-pretty text-base leading-relaxed text-slate-300 sm:text-lg"
          >
            Helping Data Fiduciaries and Processors bridge the gap between Indian legal compliance and technical execution.
            From consent orchestration to audit-ready cloud architecture.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.24, ease: [0.22, 1, 0.36, 1] }}
            className="mt-9 flex flex-col gap-3 sm:flex-row"
          >
            <Button size="lg" onClick={() => open({ intent: "audit" })}>
              <CalendarCheck /> Schedule Compliance Audit
              <ArrowRight className="transition-transform group-hover:translate-x-0.5" />
            </Button>
            <Button size="lg" variant="outline-dark" asChild>
              <a href="#assessment">
                <Gauge /> Run Free Readiness Check
              </a>
            </Button>
          </motion.div>

          <motion.ul
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.6 }}
            className="mt-9 flex flex-wrap gap-x-6 gap-y-2 text-sm text-slate-400"
          >
            {["Legal + Technical in one team", "Fixed-scope engagements", "Works with your counsel & IT"].map((t) => (
              <li key={t} className="inline-flex items-center gap-2">
                <BadgeCheck className="h-4 w-4 text-accent" /> {t}
              </li>
            ))}
          </motion.ul>
        </div>

        <DashboardMock />
      </div>

      {/* Stats ticker */}
      <div className="relative border-y border-white/10 bg-navy-950/60 py-4 backdrop-blur">
        <div className="flex overflow-hidden [mask-image:linear-gradient(90deg,transparent,black_10%,black_90%,transparent)]">
          <div className="flex shrink-0 animate-marquee items-center gap-12 pr-12 hover:[animation-play-state:paused]">
            {[...TICKER, ...TICKER, ...TICKER, ...TICKER].map((t, i) => (
              <span key={i} className="inline-flex shrink-0 items-center gap-2.5 text-sm font-semibold text-slate-200">
                <t.icon className="h-4 w-4 text-accent" />
                {t.text}
                <span className="ml-10 h-1 w-1 rounded-full bg-slate-600" />
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
