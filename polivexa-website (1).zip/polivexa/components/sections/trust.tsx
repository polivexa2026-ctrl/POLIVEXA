"use client";
import { ArrowUpRight, Award, BadgeCheck, Building, FileLock2, Globe, HeartPulse, Landmark, ShieldCheck, ShoppingCart, Cloud, Users } from "lucide-react";
import { SectionHeading } from "@/components/section-heading";
import { CountUp, Reveal, Stagger, StaggerItem } from "@/components/motion";
import { Badge } from "@/components/ui/badge";
import { useLeadModal } from "@/components/lead/lead-modal";

const FRAMEWORKS = [
  { name: "DPDP Act 2023", sub: "& DPDP Rules 2025", icon: FileLock2 },
  { name: "CERT-In", sub: "Directions & Guidelines", icon: ShieldCheck },
  { name: "ISO/IEC 27701", sub: "Privacy Information Mgmt.", icon: Award },
  { name: "ISO/IEC 27001", sub: "Information Security", icon: BadgeCheck },
  { name: "SOC 2 Type II", sub: "Trust Services Criteria", icon: Building },
  { name: "GDPR", sub: "EU / UK alignment", icon: Globe },
];

// NOTE: Illustrative engagement snapshots. Replace with client-approved case studies before launch.
const CASES = [
  {
    icon: Landmark,
    industry: "FinTech",
    title: "Digital lending platform",
    challenge: "Consent scattered across app, web and partner NBFC journeys; RBI and DPDP obligations overlapping.",
    result: "Unified purpose-level consent ledger with withdrawal propagated to lending partners via API.",
    metrics: [{ k: "Systems mapped", v: "38" }, { k: "DPR SLA", v: "< 7 days" }],
  },
  {
    icon: ShoppingCart,
    industry: "E-Commerce",
    title: "Multi-brand D2C marketplace",
    challenge: "Marketing stack tracking users without itemised notice; no language support beyond English.",
    result: "Consent-gated tag management and notices rolled out in 11 Indian languages at checkout.",
    metrics: [{ k: "Trackers governed", v: "120+" }, { k: "Languages live", v: "11" }],
  },
  {
    icon: Cloud,
    industry: "SaaS",
    title: "B2B HR-tech platform",
    challenge: "Acting as processor for 400+ fiduciary customers with inconsistent DPAs and no deletion proof.",
    result: "Standardised DPA, tenant-level deletion certificates and ISO 27001 + 27701 control mapping.",
    metrics: [{ k: "DPAs harmonised", v: "400+" }, { k: "Audit findings", v: "−70%" }],
  },
  {
    icon: HeartPulse,
    industry: "Healthcare",
    title: "Hospital & diagnostics network",
    challenge: "Sensitive patient records across HIS, LIS and PACS; breach playbook untested.",
    result: "Encryption-at-rest across clinical systems and a 72-hour breach framework validated through drills.",
    metrics: [{ k: "Records classified", v: "9M+" }, { k: "Mock drills run", v: "4" }],
  },
];

const STATS = [
  { v: 40, suffix: "+", k: "DPDP control checkpoints in our assessment" },
  { v: 23, suffix: "", k: "Notice languages supported (22 + English)" },
  { v: 72, suffix: "h", k: "Breach reporting framework, drilled and documented" },
  { v: 6, suffix: "", k: "Frameworks mapped into one control matrix" },
];

export function Trust() {
  const { open } = useLeadModal();
  return (
    <section id="about" className="section-pad relative overflow-hidden bg-slate-50">
      <div className="container">
        <SectionHeading
          eyebrow="Trust & authority"
          title="Built on the frameworks your auditors and regulators already trust."
          description="POLIVEXA is a privacy-engineering consultancy: legal-domain experts, cloud architects and security engineers working as one delivery team for Indian and global enterprises."
        />

        {/* Frameworks */}
        <Stagger className="mt-12 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          {FRAMEWORKS.map((f) => (
            <StaggerItem key={f.name}>
              <div className="group flex h-full flex-col items-center rounded-2xl border border-slate-200 bg-white p-5 text-center transition hover:-translate-y-1 hover:border-accent/40 hover:shadow-lg">
                <span className="flex h-12 w-12 items-center justify-center rounded-full bg-navy text-accent ring-4 ring-slate-100 transition group-hover:ring-accent/20">
                  <f.icon className="h-5 w-5" />
                </span>
                <p className="mt-3 text-sm font-bold text-navy">{f.name}</p>
                <p className="mt-0.5 text-[11px] text-slate-500">{f.sub}</p>
              </div>
            </StaggerItem>
          ))}
        </Stagger>

        {/* Stats */}
        <Reveal className="mt-10 grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-slate-200 bg-slate-200 lg:grid-cols-4">
          {STATS.map((s) => (
            <div key={s.k} className="bg-white p-6 text-center sm:p-7">
              <p className="text-3xl font-extrabold tracking-[-0.012em] text-navy sm:text-4xl">
                <CountUp value={s.v} />
                <span className="text-[#00A58D]">{s.suffix}</span>
              </p>
              <p className="mx-auto mt-2 max-w-[200px] text-xs leading-snug text-slate-500 sm:text-[13px]">{s.k}</p>
            </div>
          ))}
        </Reveal>

        {/* Case studies */}
        <div className="mt-20 flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-end">
          <Reveal>
            <h3 className="text-2xl font-extrabold tracking-[-0.012em] text-navy sm:text-3xl">Engagement snapshots</h3>
            <p className="mt-2 max-w-xl text-sm text-slate-600">
              Representative engagement patterns across regulated sectors. Detailed, client-approved case studies available under NDA.
            </p>
          </Reveal>
          <button
            onClick={() => open({ intent: "consultation", context: { request: "Case studies under NDA" } })}
            className="group inline-flex items-center gap-1.5 text-sm font-semibold text-navy hover:text-[#00937F]"
          >
            Request case studies <ArrowUpRight className="h-4 w-4 transition group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
          </button>
        </div>

        <Stagger className="mt-8 grid gap-5 md:grid-cols-2">
          {CASES.map((c) => (
            <StaggerItem key={c.industry}>
              <article className="group flex h-full flex-col rounded-2xl border border-slate-200 bg-white p-6 transition-all duration-300 hover:-translate-y-1 hover:border-accent/40 hover:shadow-[0_24px_48px_-24px_rgba(10,25,47,0.25)] sm:p-7">
                <div className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-accent/10 text-[#00A58D] ring-1 ring-accent/25">
                      <c.icon className="h-5 w-5" />
                    </span>
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wider text-[#00937F]">{c.industry}</p>
                      <p className="font-bold text-navy">{c.title}</p>
                    </div>
                  </div>
                  <Badge variant="secondary" className="shrink-0">Illustrative</Badge>
                </div>
                <dl className="mt-5 space-y-3 text-sm leading-relaxed">
                  <div>
                    <dt className="font-semibold text-slate-800">Challenge</dt>
                    <dd className="text-slate-600">{c.challenge}</dd>
                  </div>
                  <div>
                    <dt className="font-semibold text-slate-800">What we delivered</dt>
                    <dd className="text-slate-600">{c.result}</dd>
                  </div>
                </dl>
                <div className="mt-auto grid grid-cols-2 gap-3 pt-6">
                  {c.metrics.map((m) => (
                    <div key={m.k} className="rounded-xl bg-slate-50 p-3 ring-1 ring-slate-100">
                      <p className="text-xl font-extrabold text-navy">{m.v}</p>
                      <p className="text-xs text-slate-500">{m.k}</p>
                    </div>
                  ))}
                </div>
              </article>
            </StaggerItem>
          ))}
        </Stagger>

        {/* About strip */}
        <Reveal className="mt-16 grid gap-6 rounded-2xl border border-slate-200 bg-white p-6 sm:p-8 md:grid-cols-3">
          {[
            { icon: Users, t: "Multidisciplinary bench", d: "Privacy-law specialists, cloud architects, security engineers and certified auditors on one engagement." },
            { icon: Globe, t: "India-first, globally aligned", d: "DPDP at the core, mapped to GDPR, ISO and SOC 2 for multinationals and exporters of digital services." },
            { icon: ShieldCheck, t: "Implementation, not just advice", d: "We ship the consent SDK, the DPR portal and the evidence trail — then help you run it." },
          ].map((x) => (
            <div key={x.t} className="flex gap-4">
              <x.icon className="mt-0.5 h-6 w-6 shrink-0 text-accent" />
              <div>
                <p className="font-bold text-navy">{x.t}</p>
                <p className="mt-1 text-sm leading-relaxed text-slate-600">{x.d}</p>
              </div>
            </div>
          ))}
        </Reveal>
      </div>
    </section>
  );
}
