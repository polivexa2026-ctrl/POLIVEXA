"use client";
import * as React from "react";
import { AnimatePresence, motion } from "framer-motion";
import { AlertTriangle, CheckCircle2, Download, Info, RotateCcw, ShieldAlert, ShieldCheck, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SectionHeading } from "@/components/section-heading";
import { useLeadModal } from "@/components/lead/lead-modal";
import { PREPAREDNESS_STAGES } from "@/components/lead/lead-form";
import { cn } from "@/lib/utils";

type Option = { label: string; value: string; points: number; gap?: string };
type Question = { id: string; q: string; hint: string; options: Option[] };

const QUESTIONS: Question[] = [
  {
    id: "scope",
    q: "Do you store or process personal data of Indian residents digitally?",
    hint: "Includes data collected offline and later digitised, and processing outside India for offering goods or services in India.",
    options: [
      { label: "Yes", value: "yes", points: 15 },
      { label: "No", value: "no", points: 15 },
      { label: "Not sure", value: "unsure", points: 0, gap: "No reliable personal-data inventory — applicability and scope are unknown (RoPA & PII discovery needed)." },
    ],
  },
  {
    id: "rights",
    q: "Can you systematically process consent withdrawal and right to erasure?",
    hint: "Withdrawal must be as easy as giving consent, and erasure must reach processors and backups per retention rules.",
    options: [
      { label: "Yes, automated", value: "yes", points: 40 },
      { label: "Partially / manual", value: "partial", points: 18, gap: "Withdrawal and erasure depend on manual steps — high risk of missed downstream systems and processors." },
      { label: "No", value: "no", points: 0, gap: "No mechanism for consent withdrawal or erasure — a core Data Principal right under Sections 6 and 12." },
    ],
  },
  {
    id: "breach",
    q: "Do you have an automated breach notification mechanism?",
    hint: "DPDP requires intimation to the Board and each affected Data Principal; CERT-In requires reporting within 6 hours.",
    options: [
      { label: "Yes, tested", value: "yes", points: 35 },
      { label: "Partially / untested", value: "partial", points: 15, gap: "Breach response exists on paper but is untested — the 72-hour detailed Board report window is at risk." },
      { label: "No", value: "no", points: 0, gap: "No breach notification framework — failure to notify carries penalties up to ₹200 Cr." },
    ],
  },
  {
    id: "children",
    q: "Do you collect personal data of children or persons with disabilities?",
    hint: "Triggers verifiable parental / lawful-guardian consent and a ban on tracking or targeted advertising to children.",
    options: [
      { label: "Yes", value: "yes", points: 0, gap: "Children’s / guardian data triggers verifiable consent and no-tracking obligations (penalty up to ₹200 Cr)." },
      { label: "No", value: "no", points: 10 },
      { label: "Not sure", value: "unsure", points: 0, gap: "Unclear whether children’s data is collected — age-gating and verifiable parental consent need assessment." },
    ],
  },
];

function band(score: number) {
  if (score >= 90) return { label: "Strong", color: "#10B981", icon: ShieldCheck, stage: PREPAREDNESS_STAGES[3], text: "Solid foundations. Validate with an independent audit and mock drills." };
  if (score >= 65) return { label: "Developing", color: "#00D2B4", icon: ShieldCheck, stage: PREPAREDNESS_STAGES[2], text: "Good progress, but key workflows still need hardening before enforcement." };
  if (score >= 35) return { label: "At Risk", color: "#F59E0B", icon: AlertTriangle, stage: PREPAREDNESS_STAGES[1], text: "Material gaps in core obligations. Prioritise rights and breach workflows." };
  return { label: "Critical", color: "#F43F5E", icon: ShieldAlert, stage: PREPAREDNESS_STAGES[0], text: "Significant exposure. A structured gap assessment is strongly recommended." };
}

export function ReadinessCalculator() {
  const { open } = useLeadModal();
  const [answers, setAnswers] = React.useState<Record<string, Option | undefined>>({});

  const answered = QUESTIONS.filter((q) => answers[q.id]).length;
  const complete = answered === QUESTIONS.length;
  const score = QUESTIONS.reduce((s, q) => s + (answers[q.id]?.points ?? 0), 0);
  const b = band(score);
  const gaps = QUESTIONS.map((q) => answers[q.id]?.gap).filter(Boolean) as string[];
  const outOfScope = answers.scope?.value === "no";

  const R = 70;
  const C = 2 * Math.PI * R;

  return (
    <section id="assessment" className="section-pad relative overflow-hidden bg-navy-900">
      <div className="absolute inset-0 bg-grid-light bg-[size:56px_56px] [mask-image:radial-gradient(ellipse_70%_60%_at_50%_40%,black,transparent)]" />
      <div className="absolute left-0 top-1/3 h-96 w-96 rounded-full bg-accent/10 blur-[120px]" />
      <div className="container relative">
        <SectionHeading
          dark
          eyebrow="Enterprise assessment · Free"
          title={<>How DPDP-ready are you? <span className="text-gradient">Find out in 60 seconds.</span></>}
          description="Answer four questions for an instant, indicative readiness score and the priority gaps to close first."
        />

        <div className="mt-14 grid gap-6 lg:grid-cols-[1.25fr_1fr]">
          {/* Questions */}
          <div className="space-y-4">
            {QUESTIONS.map((q, qi) => (
              <motion.fieldset
                key={q.id}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: qi * 0.08, duration: 0.5 }}
                className={cn(
                  "glass rounded-2xl p-5 transition-colors sm:p-6",
                  answers[q.id] && "border-accent/30"
                )}
              >
                <legend className="sr-only">{q.q}</legend>
                <div className="flex gap-4">
                  <span
                    className={cn(
                      "flex h-8 w-8 shrink-0 items-center justify-center rounded-full text-sm font-bold transition-colors",
                      answers[q.id] ? "bg-accent text-navy" : "bg-white/10 text-slate-300"
                    )}
                  >
                    {answers[q.id] ? <CheckCircle2 className="h-4 w-4" /> : qi + 1}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="font-semibold leading-snug text-white">{q.q}</p>
                    <p className="mt-1.5 flex gap-1.5 text-xs leading-relaxed text-slate-400">
                      <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-slate-500" /> {q.hint}
                    </p>
                    <div className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-3" role="radiogroup" aria-label={q.q}>
                      {q.options.map((o) => {
                        const selected = answers[q.id]?.value === o.value;
                        return (
                          <button
                            key={o.value}
                            role="radio"
                            aria-checked={selected}
                            onClick={() => setAnswers((a) => ({ ...a, [q.id]: o }))}
                            className={cn(
                              "relative rounded-lg border px-3 py-2.5 text-sm font-semibold transition-all active:scale-[0.98]",
                              selected
                                ? "border-accent bg-accent/15 text-white shadow-[0_0_0_3px_rgba(0,210,180,0.15)]"
                                : "border-white/10 bg-white/[0.03] text-slate-300 hover:border-white/25 hover:bg-white/[0.06]"
                            )}
                          >
                            {o.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </motion.fieldset>
            ))}
          </div>

          {/* Result */}
          <div className="lg:sticky lg:top-24 lg:self-start">
            <div className="glass rounded-2xl bg-navy-800/70 p-6 sm:p-7">
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold text-white">Your DPDP readiness</p>
                <span className="text-xs text-slate-400">{answered}/4 answered</span>
              </div>
              <div className="mt-2 h-1 overflow-hidden rounded-full bg-white/10">
                <motion.div className="h-full bg-accent" animate={{ width: `${(answered / 4) * 100}%` }} />
              </div>

              <div className="mt-7 flex flex-col items-center">
                <div className="relative h-44 w-44">
                  <svg viewBox="0 0 160 160" className="h-44 w-44 -rotate-90">
                    <circle cx="80" cy="80" r={R} stroke="rgba(255,255,255,0.08)" strokeWidth="12" fill="none" />
                    <motion.circle
                      cx="80"
                      cy="80"
                      r={R}
                      strokeWidth="12"
                      fill="none"
                      strokeLinecap="round"
                      strokeDasharray={C}
                      animate={{ strokeDashoffset: C * (1 - score / 100), stroke: complete ? b.color : "#00D2B4" }}
                      initial={{ strokeDashoffset: C }}
                      transition={{ duration: 0.8, ease: "easeOut" }}
                    />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <motion.span key={score} initial={{ scale: 0.85, opacity: 0.4 }} animate={{ scale: 1, opacity: 1 }} className="text-5xl font-extrabold text-white">
                      {score}
                    </motion.span>
                    <span className="text-xs font-medium text-slate-400">out of 100</span>
                  </div>
                </div>

                <AnimatePresence mode="wait">
                  {complete ? (
                    <motion.div key="band" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="mt-5 text-center">
                      <span
                        className="inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-sm font-bold"
                        style={{ color: b.color, backgroundColor: `${b.color}1f`, boxShadow: `inset 0 0 0 1px ${b.color}55` }}
                      >
                        <b.icon className="h-4 w-4" /> {b.label}
                      </span>
                      <p className="mx-auto mt-3 max-w-xs text-sm leading-relaxed text-slate-300">
                        {outOfScope
                          ? "You may have limited direct applicability — but processors, group entities and offline-to-digital data often change that. Confirm scope with a quick review."
                          : b.text}
                      </p>
                    </motion.div>
                  ) : (
                    <motion.p key="prompt" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="mt-5 text-center text-sm text-slate-400">
                      Answer all four questions to see your readiness band.
                    </motion.p>
                  )}
                </AnimatePresence>
              </div>

              <AnimatePresence>
                {complete && gaps.length > 0 && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
                    <p className="mt-6 text-xs font-semibold uppercase tracking-wider text-slate-400">Priority gaps ({gaps.length})</p>
                    <ul className="mt-3 space-y-2.5">
                      {gaps.map((g) => (
                        <li key={g} className="flex gap-2.5 rounded-lg bg-white/[0.03] p-3 text-[13px] leading-snug text-slate-300 ring-1 ring-white/10">
                          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-amber-400" /> {g}
                        </li>
                      ))}
                    </ul>
                  </motion.div>
                )}
                {complete && gaps.length === 0 && (
                  <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-6 flex gap-2.5 rounded-lg bg-emerald-400/10 p-3 text-[13px] text-emerald-300 ring-1 ring-emerald-400/20">
                    <Sparkles className="h-4 w-4 shrink-0" /> No critical gaps flagged. The full assessment checks 40+ further controls.
                  </motion.p>
                )}
              </AnimatePresence>

              <div className="mt-7 grid gap-2.5">
                <Button
                  size="lg"
                  disabled={!complete}
                  onClick={() =>
                    open({
                      intent: "gap-assessment",
                      defaultStage: b.stage,
                      context: {
                        score,
                        band: b.label,
                        answers: Object.fromEntries(QUESTIONS.map((q) => [q.id, answers[q.id]?.value])),
                      },
                    })
                  }
                >
                  <Download /> Download Comprehensive Gap Assessment
                </Button>
                {answered > 0 && (
                  <Button variant="ghost-dark" size="sm" onClick={() => setAnswers({})}>
                    <RotateCcw /> Start over
                  </Button>
                )}
              </div>
              <p className="mt-4 text-center text-[11px] leading-relaxed text-slate-500">
                Indicative self-assessment only; not legal advice. Your answers stay in your browser until you request the report.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
