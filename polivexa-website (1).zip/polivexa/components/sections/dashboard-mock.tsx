"use client";
import * as React from "react";
import { AnimatePresence, motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import {
  Activity,
  AlertTriangle,
  BellRing,
  CheckCircle2,
  Clock3,
  Eraser,
  FileSearch,
  Globe2,
  Languages,
  PencilLine,
  RefreshCcw,
  ShieldCheck,
  Timer,
  UserCheck,
} from "lucide-react";
import { cn } from "@/lib/utils";

type View = "consent" | "rights" | "breach";

const VIEWS: { id: View; label: string }[] = [
  { id: "consent", label: "Consent" },
  { id: "rights", label: "Rights & Grievance" },
  { id: "breach", label: "Breach" },
];

const BARS = [42, 58, 51, 66, 72, 64, 80, 77, 88, 84, 92, 96];

const REQUESTS = [
  { id: "DPR-2291", type: "Erasure", icon: Eraser, sla: "2d 4h", pct: 78, status: "Propagating" },
  { id: "DPR-2288", type: "Access", icon: FileSearch, sla: "5d 11h", pct: 40, status: "In review" },
  { id: "GRV-0417", type: "Grievance", icon: AlertTriangle, sla: "9d 2h", pct: 22, status: "Assigned" },
  { id: "DPR-2285", type: "Correction", icon: PencilLine, sla: "Closed", pct: 100, status: "Fulfilled" },
];

const LANGS = ["English", "हिन्दी", "தமிழ்", "বাংলা", "తెలుగు", "मराठी", "ગુજરાતી", "ಕನ್ನಡ", "മലയാളം", "ଓଡ଼ିଆ", "ਪੰਜਾਬੀ", "اردو"];

export function DashboardMock() {
  const [view, setView] = React.useState<View>("consent");
  const [auto, setAuto] = React.useState(true);

  // Auto-cycle views until the user interacts
  React.useEffect(() => {
    if (!auto) return;
    const t = setInterval(() => {
      setView((v) => (v === "consent" ? "rights" : v === "rights" ? "breach" : "consent"));
    }, 5200);
    return () => clearInterval(t);
  }, [auto]);

  // Subtle 3D tilt on pointer move
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const rx = useSpring(useTransform(my, [-0.5, 0.5], [5, -5]), { stiffness: 120, damping: 18 });
  const ry = useSpring(useTransform(mx, [-0.5, 0.5], [-6, 6]), { stiffness: 120, damping: 18 });

  return (
    <div
      className="relative mx-auto w-full max-w-[560px] [perspective:1400px]"
      onPointerMove={(e) => {
        if (e.pointerType !== "mouse") return;
        const r = e.currentTarget.getBoundingClientRect();
        mx.set((e.clientX - r.left) / r.width - 0.5);
        my.set((e.clientY - r.top) / r.height - 0.5);
      }}
      onPointerLeave={() => {
        mx.set(0);
        my.set(0);
      }}
    >
      {/* Glow */}
      <div className="pointer-events-none absolute -inset-10 rounded-[40px] bg-[radial-gradient(closest-side,rgba(0,210,180,0.25),transparent)] blur-2xl" />

      <motion.div
        style={{ rotateX: rx, rotateY: ry }}
        initial={{ opacity: 0, y: 40, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.9, delay: 0.25, ease: [0.22, 1, 0.36, 1] }}
        className="glass relative overflow-hidden rounded-2xl bg-navy-800/60 [transform-style:preserve-3d]"
      >
        {/* Window chrome */}
        <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
          <div className="flex items-center gap-2">
            <span className="h-2.5 w-2.5 rounded-full bg-rose-400/70" />
            <span className="h-2.5 w-2.5 rounded-full bg-amber-300/70" />
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-400/70" />
            <span className="ml-3 hidden text-xs font-medium text-slate-400 sm:inline">
              DPDP Consent &amp; Grievance Governance
            </span>
          </div>
          <span className="inline-flex items-center gap-1.5 rounded-full bg-accent/10 px-2 py-0.5 text-[10px] font-semibold text-accent ring-1 ring-accent/25">
            <span className="relative flex h-1.5 w-1.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-accent opacity-75" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-accent" />
            </span>
            LIVE
          </span>
        </div>

        {/* View switcher */}
        <div className="flex gap-1 border-b border-white/10 px-3 pt-3" role="tablist" aria-label="Dashboard views">
          {VIEWS.map((v) => (
            <button
              key={v.id}
              role="tab"
              aria-selected={view === v.id}
              onClick={() => {
                setAuto(false);
                setView(v.id);
              }}
              className={cn(
                "relative rounded-t-md px-3 pb-2.5 pt-1 text-xs font-semibold transition-colors",
                view === v.id ? "text-white" : "text-slate-400 hover:text-slate-200"
              )}
            >
              {v.label}
              {view === v.id && (
                <motion.span layoutId="dash-tab" className="absolute inset-x-2 -bottom-px h-0.5 rounded-full bg-accent" />
              )}
            </button>
          ))}
        </div>

        <div className="relative min-h-[330px] p-4 sm:min-h-[318px] sm:p-5">
          <AnimatePresence mode="wait">
            {view === "consent" && (
              <motion.div key="consent" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.3 }}>
                <div className="grid grid-cols-3 gap-2.5">
                  {[
                    { k: "Active consents", v: "4.82M", d: "+3.1%", icon: UserCheck },
                    { k: "Withdrawals (24h)", v: "1,204", d: "synced", icon: RefreshCcw },
                    { k: "Notice languages", v: "22 + EN", d: "8th Sch.", icon: Languages },
                  ].map((s) => (
                    <div key={s.k} className="rounded-xl border border-white/10 bg-white/[0.03] p-2.5 sm:p-3">
                      <s.icon className="h-4 w-4 text-accent" />
                      <p className="mt-2 text-base font-bold text-white sm:text-lg">{s.v}</p>
                      <p className="text-[10px] leading-tight text-slate-400 sm:text-[11px]">{s.k}</p>
                      <p className="mt-1 text-[10px] font-semibold text-emerald-400">{s.d}</p>
                    </div>
                  ))}
                </div>
                <div className="mt-3 rounded-xl border border-white/10 bg-white/[0.03] p-3">
                  <div className="flex items-center justify-between">
                    <p className="text-xs font-semibold text-slate-200">Purpose-bound consent capture rate</p>
                    <span className="text-xs font-bold text-accent">96.4%</span>
                  </div>
                  <div className="mt-3 flex h-20 items-end gap-1.5">
                    {BARS.map((h, i) => (
                      <motion.span
                        key={i}
                        initial={{ height: 0 }}
                        animate={{ height: `${h}%` }}
                        transition={{ delay: 0.05 * i, duration: 0.5, ease: "easeOut" }}
                        className={cn(
                          "flex-1 rounded-t-sm",
                          i === BARS.length - 1 ? "bg-accent" : "bg-gradient-to-t from-accent/20 to-accent/60"
                        )}
                      />
                    ))}
                  </div>
                </div>
                <div className="mt-3 flex flex-wrap gap-1.5">
                  {LANGS.map((l, i) => (
                    <motion.span
                      key={l}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: 0.3 + i * 0.04 }}
                      className={cn(
                        "rounded-md px-2 py-0.5 text-[11px] font-medium ring-1",
                        i === 1 ? "bg-accent/15 text-accent ring-accent/30" : "bg-white/5 text-slate-300 ring-white/10"
                      )}
                    >
                      {l}
                    </motion.span>
                  ))}
                </div>
              </motion.div>
            )}

            {view === "rights" && (
              <motion.div key="rights" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.3 }}>
                <div className="flex items-center justify-between">
                  <p className="text-xs font-semibold text-slate-200">Data Principal requests</p>
                  <span className="text-[11px] text-slate-400">SLA on track · 98.7%</span>
                </div>
                <ul className="mt-3 space-y-2">
                  {REQUESTS.map((r, i) => (
                    <motion.li
                      key={r.id}
                      initial={{ opacity: 0, x: -12 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.08 }}
                      className="rounded-xl border border-white/10 bg-white/[0.03] p-2.5"
                    >
                      <div className="flex items-center gap-3">
                        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-white/5 text-accent ring-1 ring-white/10">
                          <r.icon className="h-4 w-4" />
                        </span>
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center justify-between gap-2">
                            <p className="truncate text-xs font-semibold text-white">
                              {r.type} <span className="font-normal text-slate-500">· {r.id}</span>
                            </p>
                            <span
                              className={cn(
                                "shrink-0 text-[10px] font-semibold",
                                r.pct === 100 ? "text-emerald-400" : "text-slate-400"
                              )}
                            >
                              {r.pct === 100 ? <CheckCircle2 className="mr-1 inline h-3 w-3" /> : <Clock3 className="mr-1 inline h-3 w-3" />}
                              {r.sla}
                            </span>
                          </div>
                          <div className="mt-1.5 h-1 overflow-hidden rounded-full bg-white/10">
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${r.pct}%` }}
                              transition={{ delay: 0.2 + i * 0.08, duration: 0.7 }}
                              className={cn("h-full rounded-full", r.pct === 100 ? "bg-emerald-400" : "bg-accent")}
                            />
                          </div>
                          <p className="mt-1 text-[10px] text-slate-400">{r.status}</p>
                        </div>
                      </div>
                    </motion.li>
                  ))}
                </ul>
              </motion.div>
            )}

            {view === "breach" && (
              <motion.div key="breach" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }} transition={{ duration: 0.3 }}>
                <div className="flex items-center gap-4 rounded-xl border border-white/10 bg-white/[0.03] p-3">
                  <div className="relative h-20 w-20 shrink-0">
                    <svg viewBox="0 0 80 80" className="h-20 w-20 -rotate-90">
                      <circle cx="40" cy="40" r="34" stroke="rgba(255,255,255,0.1)" strokeWidth="7" fill="none" />
                      <motion.circle
                        cx="40"
                        cy="40"
                        r="34"
                        stroke="#00D2B4"
                        strokeWidth="7"
                        fill="none"
                        strokeLinecap="round"
                        strokeDasharray={2 * Math.PI * 34}
                        initial={{ strokeDashoffset: 2 * Math.PI * 34 }}
                        animate={{ strokeDashoffset: 2 * Math.PI * 34 * (1 - 0.82) }}
                        transition={{ duration: 1, ease: "easeOut" }}
                      />
                    </svg>
                    <span className="absolute inset-0 flex flex-col items-center justify-center">
                      <Timer className="h-4 w-4 text-accent" />
                      <span className="text-[11px] font-bold text-white">59h left</span>
                    </span>
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-white">72-hour Board report window</p>
                    <p className="mt-1 text-[11px] leading-snug text-slate-400">
                      Incident INC-073 · intimation to DPBI &amp; affected Data Principals prepared. CERT-In 6-hr report filed.
                    </p>
                  </div>
                </div>
                <ol className="mt-3 space-y-2">
                  {[
                    { t: "Detected & contained", s: "T+00:42", done: true, icon: ShieldCheck },
                    { t: "CERT-In incident report", s: "T+05:10", done: true, icon: Globe2 },
                    { t: "Data Principals notified", s: "T+11:30", done: true, icon: BellRing },
                    { t: "Detailed report to Board", s: "Due T+72", done: false, icon: Activity },
                  ].map((x, i) => (
                    <motion.li
                      key={x.t}
                      initial={{ opacity: 0, x: 12 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.1 + i * 0.08 }}
                      className="flex items-center gap-3 rounded-lg px-1"
                    >
                      <span
                        className={cn(
                          "flex h-7 w-7 items-center justify-center rounded-full ring-1",
                          x.done ? "bg-accent/15 text-accent ring-accent/30" : "bg-amber-400/10 text-amber-300 ring-amber-300/30"
                        )}
                      >
                        <x.icon className="h-3.5 w-3.5" />
                      </span>
                      <span className="flex-1 text-xs text-slate-200">{x.t}</span>
                      <span className={cn("text-[11px] font-semibold", x.done ? "text-slate-400" : "text-amber-300")}>{x.s}</span>
                    </motion.li>
                  ))}
                </ol>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>

      {/* Floating micro-cards */}
      <motion.div
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 1, duration: 0.6 }}
        className="glass absolute -bottom-8 -left-4 hidden animate-float items-center gap-3 rounded-xl bg-navy-900/80 px-3.5 py-2.5 sm:flex xl:-left-12"
      >
        <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-400/15 text-emerald-400">
          <RefreshCcw className="h-4 w-4" />
        </span>
        <div>
          <p className="text-xs font-semibold text-white">Consent withdrawn</p>
          <p className="text-[11px] text-slate-400">Propagated to 14 systems · 1.8s</p>
        </div>
      </motion.div>
      <motion.div
        initial={{ opacity: 0, x: 20 }}
        animate={{ opacity: 1, x: 0 }}
        transition={{ delay: 1.2, duration: 0.6 }}
        className="glass absolute -right-3 -top-5 hidden items-center gap-2.5 rounded-xl bg-navy-900/80 px-3.5 py-2.5 [animation-delay:1.5s] animate-float sm:flex xl:-right-10"
      >
        <ShieldCheck className="h-5 w-5 text-accent" />
        <div>
          <p className="text-xs font-semibold text-white">Audit trail sealed</p>
          <p className="text-[11px] text-slate-400">SHA-256 · immutable log</p>
        </div>
      </motion.div>
    </div>
  );
}
