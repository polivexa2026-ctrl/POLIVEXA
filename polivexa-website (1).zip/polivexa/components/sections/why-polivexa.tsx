"use client";
import { motion } from "framer-motion";
import {
  ArrowLeftRight,
  Baby,
  Building2,
  Code2,
  DatabaseZap,
  FileCheck2,
  FileText,
  Gavel,
  KeyRound,
  Languages,
  Network,
  Scale,
  ScrollText,
  ToggleRight,
} from "lucide-react";
import { SectionHeading } from "@/components/section-heading";
import { CountUp, Stagger, StaggerItem } from "@/components/motion";
import { cn } from "@/lib/utils";

const PENALTIES = [
  { label: "Failure to take reasonable security safeguards", cr: 250 },
  { label: "Failure to notify a personal data breach", cr: 200 },
  { label: "Breach of children's data obligations", cr: 200 },
  { label: "Breach of Significant Data Fiduciary obligations", cr: 150 },
  { label: "Other breaches of the Act / Rules", cr: 50 },
];

function BentoCard({ className, children }: { className?: string; children: React.ReactNode }) {
  return (
    <StaggerItem
      className={cn(
        "group relative overflow-hidden rounded-2xl border border-slate-200 bg-white p-6 transition-all duration-300 hover:-translate-y-1 hover:border-accent/40 hover:shadow-[0_24px_48px_-24px_rgba(10,25,47,0.25)] sm:p-7",
        className
      )}
    >
      {children}
    </StaggerItem>
  );
}

function IconChip({ icon: Icon, className }: { icon: typeof Gavel; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex h-11 w-11 items-center justify-center rounded-xl bg-accent/10 text-[#00A58D] ring-1 ring-accent/25 transition group-hover:scale-105 group-hover:bg-accent group-hover:text-navy",
        className
      )}
    >
      <Icon className="h-5 w-5" />
    </span>
  );
}

export function WhyPolivexa() {
  return (
    <section id="platform" className="section-pad relative overflow-hidden bg-slate-50">
      <div className="absolute inset-0 bg-grid-dark bg-[size:48px_48px] [mask-image:linear-gradient(to_bottom,black,transparent_60%)]" />
      <div className="container relative">
        <SectionHeading
          eyebrow="The DPDP reality"
          title={
            <>
              The DPDP Act rewrote the rules.
              <br className="hidden sm:block" /> Most programs only solve <span className="text-[#00A58D]">half the problem</span>.
            </>
          }
          description="Lawyers draft the policy. IT teams guess at the implementation. The gap between them is exactly where penalties, failed audits and broken customer trust live."
        />

        <Stagger className="mt-14 grid gap-4 sm:gap-5 lg:grid-cols-6">
          {/* Penalties — hero card */}
          <BentoCard className="border-navy-700 bg-navy-900 lg:col-span-3 lg:row-span-2">
            <div className="absolute -right-24 -top-24 h-64 w-64 rounded-full bg-rose-500/10 blur-3xl" />
            <div className="relative">
              <span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-rose-500/10 text-rose-400 ring-1 ring-rose-400/30">
                <Gavel className="h-5 w-5" />
              </span>
              <p className="mt-6 text-sm font-semibold uppercase tracking-wider text-slate-400">Maximum penalty per instance</p>
              <p className="mt-1 text-5xl font-extrabold tracking-[-0.012em] text-white sm:text-6xl">
                ₹<CountUp value={250} /> <span className="text-3xl text-slate-400 sm:text-4xl">Cr</span>
              </p>
              <p className="mt-3 max-w-md text-sm leading-relaxed text-slate-400">
                Levied by the Data Protection Board of India under the Schedule to the Act. Penalties apply per breach — exposure
                compounds across systems and incidents.
              </p>
              <ul className="mt-7 space-y-3.5">
                {PENALTIES.map((p, i) => (
                  <li key={p.label}>
                    <div className="flex items-baseline justify-between gap-4 text-[13px]">
                      <span className="text-slate-300">{p.label}</span>
                      <span className="shrink-0 font-bold text-white">₹{p.cr} Cr</span>
                    </div>
                    <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-white/10">
                      <motion.div
                        className="h-full rounded-full bg-gradient-to-r from-rose-500 to-amber-400"
                        initial={{ width: 0 }}
                        whileInView={{ width: `${(p.cr / 250) * 100}%` }}
                        viewport={{ once: true }}
                        transition={{ duration: 0.9, delay: 0.2 + i * 0.1, ease: "easeOut" }}
                      />
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </BentoCard>

          <BentoCard className="lg:col-span-3">
            <div className="flex items-start justify-between gap-4">
              <IconChip icon={ToggleRight} />
              <span className="rounded-full bg-amber-50 px-2.5 py-1 text-[11px] font-semibold text-amber-700 ring-1 ring-amber-200">
                Architecture overhaul
              </span>
            </div>
            <h3 className="mt-5 text-lg font-bold text-navy">Consent must be free, specific, informed &amp; withdrawable</h3>
            <p className="mt-2 text-sm leading-relaxed text-slate-600">
              Bundled checkboxes and buried T&amp;Cs no longer work. Every purpose needs itemised notice, a clear affirmative
              action, and withdrawal as easy as giving consent — propagated to every downstream system and processor.
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              {["Purpose-level consent", "Withdrawal sync", "Consent Manager ready", "Immutable logs"].map((t) => (
                <span key={t} className="rounded-md bg-slate-100 px-2.5 py-1 text-xs font-medium text-slate-600">{t}</span>
              ))}
            </div>
          </BentoCard>

          <BentoCard className="lg:col-span-3">
            <IconChip icon={Languages} />
            <h3 className="mt-5 text-lg font-bold text-navy">Notices in English or any of 22 scheduled languages</h3>
            <p className="mt-2 text-sm leading-relaxed text-slate-600">
              Data Principals can request notices in any language in the Eighth Schedule of the Constitution. That&apos;s a
              content, UX and localisation pipeline — not a one-time translation.
            </p>
            <div className="mt-5 flex -space-x-2">
              {["हि", "த", "বা", "తె", "म", "ગુ", "ಕ", "മ"].map((l) => (
                <span key={l} className="flex h-9 w-9 items-center justify-center rounded-full border-2 border-white bg-navy text-xs font-bold text-accent">
                  {l}
                </span>
              ))}
              <span className="flex h-9 w-9 items-center justify-center rounded-full border-2 border-white bg-accent text-[11px] font-bold text-navy">
                +14
              </span>
            </div>
          </BentoCard>

          <BentoCard className="lg:col-span-2">
            <IconChip icon={Scale} />
            <h3 className="mt-5 text-base font-bold text-navy">Data Protection Board scrutiny</h3>
            <p className="mt-2 text-sm leading-relaxed text-slate-600">
              A digital-first adjudicator that can inquire, direct and penalise. You need evidence on demand, not a policy PDF.
            </p>
          </BentoCard>
          <BentoCard className="lg:col-span-2">
            <IconChip icon={Baby} />
            <h3 className="mt-5 text-base font-bold text-navy">Children &amp; persons with disability</h3>
            <p className="mt-2 text-sm leading-relaxed text-slate-600">
              Verifiable consent of a parent or lawful guardian, and no tracking, behavioural monitoring or targeted ads at children.
            </p>
          </BentoCard>
          <BentoCard className="lg:col-span-2">
            <IconChip icon={Building2} />
            <h3 className="mt-5 text-base font-bold text-navy">Significant Data Fiduciaries</h3>
            <p className="mt-2 text-sm leading-relaxed text-slate-600">
              India-based DPO, independent data auditor, periodic DPIAs and algorithmic due-diligence obligations.
            </p>
          </BentoCard>

          {/* The bridge */}
          <StaggerItem className="relative overflow-hidden rounded-2xl border border-navy-700 bg-navy-900 p-6 sm:p-8 lg:col-span-6">
            <div className="absolute inset-0 bg-grid-light bg-[size:40px_40px] opacity-60" />
            <div className="absolute left-1/2 top-1/2 h-72 w-[600px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-accent/10 blur-3xl" />
            <div className="relative">
              <div className="mx-auto max-w-2xl text-center">
                <span className="eyebrow border-accent/30 bg-accent/10 text-accent">Why Polivexa</span>
                <h3 className="mt-4 text-2xl font-extrabold tracking-[-0.012em] text-white sm:text-3xl">
                  One team that speaks both <span className="text-gradient">Law</span> and <span className="text-gradient">Code</span>.
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-slate-400 sm:text-base">
                  We translate every obligation into an engineering ticket — and every engineering control back into audit evidence.
                </p>
              </div>

              <div className="mt-10 grid items-stretch gap-4 md:grid-cols-[1fr_auto_1fr] md:gap-6">
                <div className="glass rounded-2xl p-5 sm:p-6">
                  <div className="flex items-center gap-3">
                    <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/5 text-accent ring-1 ring-white/10">
                      <ScrollText className="h-5 w-5" />
                    </span>
                    <p className="font-bold text-white">Legal Compliance Advisory</p>
                  </div>
                  <ul className="mt-5 grid gap-2.5 text-sm text-slate-300 sm:grid-cols-2 md:grid-cols-1 xl:grid-cols-2">
                    {[
                      { i: FileText, t: "Privacy notices & policies" },
                      { i: FileCheck2, t: "DPAs & processor contracts" },
                      { i: Gavel, t: "Section-by-section gap analysis" },
                      { i: Scale, t: "DPB inquiry readiness" },
                    ].map((x) => (
                      <li key={x.t} className="flex items-center gap-2.5">
                        <x.i className="h-4 w-4 shrink-0 text-accent" /> {x.t}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="flex items-center justify-center">
                  <motion.span
                    className="flex h-14 w-14 items-center justify-center rounded-full bg-accent text-navy shadow-[0_0_0_8px_rgba(0,210,180,0.12),0_0_40px_rgba(0,210,180,0.5)]"
                    animate={{ rotate: [0, 180, 180, 360, 360] }}
                    transition={{ duration: 6, repeat: Infinity, times: [0, 0.2, 0.5, 0.7, 1], ease: "easeInOut" }}
                  >
                    <ArrowLeftRight className="h-6 w-6" />
                  </motion.span>
                </div>

                <div className="glass rounded-2xl p-5 sm:p-6">
                  <div className="flex items-center gap-3">
                    <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/5 text-accent ring-1 ring-white/10">
                      <Code2 className="h-5 w-5" />
                    </span>
                    <p className="font-bold text-white">Enterprise IT Implementation</p>
                  </div>
                  <ul className="mt-5 grid gap-2.5 text-sm text-slate-300 sm:grid-cols-2 md:grid-cols-1 xl:grid-cols-2">
                    {[
                      { i: Network, t: "Consent & DPR APIs" },
                      { i: DatabaseZap, t: "Automated PII discovery" },
                      { i: KeyRound, t: "Encryption & key management" },
                      { i: ScrollText, t: "Tamper-evident consent logs" },
                    ].map((x) => (
                      <li key={x.t} className="flex items-center gap-2.5">
                        <x.i className="h-4 w-4 shrink-0 text-accent" /> {x.t}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </StaggerItem>
        </Stagger>
      </div>
    </section>
  );
}
