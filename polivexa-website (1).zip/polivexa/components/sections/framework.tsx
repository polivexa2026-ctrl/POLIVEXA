"use client";
import { motion } from "framer-motion";
import { CheckCircle2, Cpu, Radar, Scale, ScanSearch } from "lucide-react";
import { SectionHeading } from "@/components/section-heading";

const STEPS = [
  {
    icon: ScanSearch,
    title: "Discover & Map",
    time: "Weeks 1–3",
    desc: "PII discovery across databases, ERPs, CRMs, data lakes and SaaS — building a living data inventory and RoPA.",
    outputs: ["Automated PII scan", "Data-flow maps", "Processor register"],
  },
  {
    icon: Scale,
    title: "Gap Analysis & Legal Alignment",
    time: "Weeks 3–6",
    desc: "Clause-by-clause gap assessment against the Act and Rules. Notices, DPAs, policies and retention schedules rewritten.",
    outputs: ["Gap & risk register", "Notices & DPAs", "Policy stack"],
  },
  {
    icon: Cpu,
    title: "Tech Orchestration",
    time: "Weeks 6–14",
    desc: "Consent SDK, DPR portal, DPO workflows, access logs and encryption deployed into your stack — not left as recommendations.",
    outputs: ["Consent SDK & APIs", "DPR / grievance portal", "Immutable access logs"],
  },
  {
    icon: Radar,
    title: "Audit & Continuous Compliance",
    time: "Ongoing",
    desc: "DPBI readiness reviews, breach mock drills, periodic DPIAs and control monitoring to keep you audit-ready as you ship.",
    outputs: ["Mock DPB inquiry", "Breach tabletop drills", "Quarterly health checks"],
  },
];

export function Framework() {
  return (
    <section id="framework" className="section-pad bg-white">
      <div className="container">
        <SectionHeading
          eyebrow="Implementation framework"
          title="From first scan to audit-ready — in four stages."
          description="A proven, fixed-scope roadmap that moves your organisation from uncertainty to demonstrable compliance, with engineering delivery built in."
        />

        <div className="relative mt-16">
          {/* Connector line (desktop) */}
          <div className="absolute left-0 right-0 top-7 hidden h-px bg-slate-200 lg:block" />
          <motion.div
            className="absolute left-0 top-7 hidden h-px origin-left bg-gradient-to-r from-accent to-emerald-500 lg:block"
            style={{ right: 0 }}
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 1.6, ease: "easeInOut" }}
          />
          {/* Connector line (mobile) */}
          <div className="absolute bottom-6 left-7 top-7 w-px bg-gradient-to-b from-accent via-emerald-500/60 to-slate-200 lg:hidden" />

          <ol className="relative grid gap-10 lg:grid-cols-4 lg:gap-6">
            {STEPS.map((s, i) => (
              <motion.li
                key={s.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ delay: 0.15 + i * 0.25, duration: 0.55, ease: [0.22, 1, 0.36, 1] }}
                className="relative flex gap-5 lg:flex-col lg:gap-0"
              >
                <div className="relative z-10 flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-navy text-accent shadow-[0_0_0_6px_white,0_10px_30px_-10px_rgba(10,25,47,0.5)]">
                  <s.icon className="h-6 w-6" />
                  <span className="absolute -right-2 -top-2 flex h-6 w-6 items-center justify-center rounded-full bg-accent text-[11px] font-extrabold text-navy ring-2 ring-white">
                    {i + 1}
                  </span>
                </div>
                <div className="flex-1 lg:mt-7">
                  <span className="text-xs font-semibold uppercase tracking-wider text-[#00937F]">
                    Step {i + 1} · {s.time}
                  </span>
                  <h3 className="mt-2 text-lg font-bold text-navy">{s.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-slate-600">{s.desc}</p>
                  <ul className="mt-4 space-y-1.5">
                    {s.outputs.map((o) => (
                      <li key={o} className="flex items-center gap-2 text-[13px] font-medium text-slate-700">
                        <CheckCircle2 className="h-4 w-4 shrink-0 text-accent" /> {o}
                      </li>
                    ))}
                  </ul>
                </div>
              </motion.li>
            ))}
          </ol>
        </div>
      </div>
    </section>
  );
}
