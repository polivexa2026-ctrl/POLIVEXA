"use client";
import { Linkedin, Mail, MapPin, ShieldCheck, Twitter } from "lucide-react";
import { Logo } from "@/components/logo";
import { goToServices, site } from "@/lib/site";

const COLS: { title: string; links: { label: string; href?: string; onClick?: () => void }[] }[] = [
  {
    title: "Solutions",
    links: [
      { label: "DPDP Compliance", onClick: () => goToServices("dpdp") },
      { label: "IT Infrastructure & Cloud", onClick: () => goToServices("it") },
      { label: "Cyber Security & VAPT", onClick: () => goToServices("it") },
      { label: "Virtual DPO", onClick: () => goToServices("dpdp") },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About Us", href: "/about" },
      { label: "Leadership", href: "/about#leadership" },
      { label: "Compliance Platform", href: "/#platform" },
      { label: "Implementation Framework", href: "/#framework" },
      { label: "Contact", href: "/#contact" },
    ],
  },
  {
    title: "Resources",
    links: [
      { label: "DPDP Readiness Scorecard", href: "/#assessment" },
      { label: "DPDP Act FAQ", href: "/#resources" },
      { label: "Engagement Snapshots", href: "/#about" },
    ],
  },
  {
    title: "Legal",
    links: [
      { label: "Privacy Policy", href: "/privacy" },
      { label: "Terms of Service", href: "/terms" },
      { label: "Grievance Redressal Officer", href: `mailto:${site.grievanceEmail}` },
      { label: "Cookie Preferences", href: "/privacy#cookies" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="border-t border-white/10 bg-navy-950 text-slate-400">
      <div className="container py-16">
        <div className="grid gap-12 lg:grid-cols-[1.3fr_2fr]">
          <div>
            <Logo />
            <p className="mt-5 max-w-sm text-sm leading-relaxed">
              Dual-track IT consulting and DPDP Act 2023 compliance consulting for Indian and global enterprises.
            </p>
            <ul className="mt-6 space-y-2.5 text-sm">
              <li className="flex items-center gap-2.5">
                <Mail className="h-4 w-4 text-accent" />
                <a href={`mailto:${site.email}`} className="hover:text-white">{site.email}</a>
              </li>
              <li className="flex items-center gap-2.5">
                <ShieldCheck className="h-4 w-4 text-accent" />
                <a href={`mailto:${site.grievanceEmail}`} className="hover:text-white">Grievance Officer: {site.grievanceEmail}</a>
              </li>
              <li className="flex items-center gap-2.5">
                <MapPin className="h-4 w-4 text-accent" /> India · Serving clients globally
              </li>
            </ul>
            <div className="mt-6 flex gap-2.5">
              {[
                { i: Linkedin, l: "LinkedIn", h: "https://www.linkedin.com/company/polivexa" },
                { i: Twitter, l: "X / Twitter", h: "https://x.com/polivexa" },
              ].map((s) => (
                <a
                  key={s.l}
                  href={s.h}
                  aria-label={s.l}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex h-9 w-9 items-center justify-center rounded-lg bg-white/5 text-slate-300 ring-1 ring-white/10 transition hover:bg-accent hover:text-navy"
                >
                  <s.i className="h-4 w-4" />
                </a>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-8 sm:grid-cols-4">
            {COLS.map((c) => (
              <div key={c.title}>
                <p className="text-sm font-semibold text-white">{c.title}</p>
                <ul className="mt-4 space-y-2.5 text-sm">
                  {c.links.map((l) => (
                    <li key={l.label}>
                      {l.onClick ? (
                        <button onClick={l.onClick} className="text-left transition hover:text-accent">{l.label}</button>
                      ) : (
                        <a href={l.href} className="transition hover:text-accent">{l.label}</a>
                      )}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div id="privacy" className="mt-14 rounded-xl border border-white/10 bg-white/[0.02] p-5 text-xs leading-relaxed text-slate-500">
          <p>
            <strong className="text-slate-300">Disclaimer:</strong> POLIVEXA is a technology and compliance consulting firm and is
            not a law firm. We do not provide legal representation or legal opinions, and nothing on this website constitutes legal
            advice or creates an advocate–client relationship. Where legal advice or representation before the Data Protection Board
            of India or any court is required, we work alongside your appointed counsel or independent legal professionals.
            Framework names are trademarks of their respective owners and are referenced for alignment purposes only.
          </p>
        </div>

        <div className="mt-8 flex flex-col gap-4 border-t border-white/10 pt-8 text-sm sm:flex-row sm:items-center sm:justify-between">
          <p>© 2026 POLIVEXA. All rights reserved.</p>
          <div className="flex flex-wrap gap-x-6 gap-y-2">
            <a href="/privacy" className="hover:text-white">Privacy Policy</a>
            <a href="/terms" className="hover:text-white">Terms of Service</a>
            <a href={`mailto:${site.grievanceEmail}`} className="hover:text-white">Grievance Redressal</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
