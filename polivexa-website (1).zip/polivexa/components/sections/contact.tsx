"use client";
import { CalendarClock, CheckCircle2, Clock, FileSearch, ShieldCheck } from "lucide-react";
import { LeadForm } from "@/components/lead/lead-form";
import { Reveal } from "@/components/motion";

export function Contact() {
  return (
    <section id="contact" className="section-pad relative overflow-hidden bg-navy-900">
      <div className="absolute inset-0 bg-grid-light bg-[size:56px_56px] [mask-image:radial-gradient(ellipse_60%_60%_at_30%_50%,black,transparent)]" />
      <div className="absolute -left-40 bottom-0 h-[420px] w-[420px] rounded-full bg-accent/15 blur-[120px]" />
      <div className="container relative grid items-center gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
        <Reveal>
          <span className="eyebrow border-accent/30 bg-accent/10 text-accent">
            <span className="h-1.5 w-1.5 rounded-full bg-accent" /> Book a consultation
          </span>
          <h2 className="mt-5 text-balance text-3xl font-extrabold leading-tight tracking-[-0.012em] text-white sm:text-4xl lg:text-[44px]">
            Get a clear, costed path to <span className="text-gradient">DPDP compliance</span>.
          </h2>
          <p className="mt-5 max-w-lg text-base leading-relaxed text-slate-300 sm:text-lg">
            Tell us where you are today. Within one business day, a specialist will come back with a scoped plan covering both the
            legal and technical workstreams.
          </p>
          <ul className="mt-8 space-y-4">
            {[
              { i: Clock, t: "30-minute scoping call", d: "With a DPDP specialist and a solutions architect." },
              { i: FileSearch, t: "Preliminary gap snapshot", d: "Your top five risks, prioritised by penalty exposure." },
              { i: CalendarClock, t: "Fixed-scope proposal", d: "Clear deliverables, timeline and investment — no surprises." },
            ].map((x) => (
              <li key={x.t} className="flex gap-4">
                <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-accent/10 text-accent ring-1 ring-accent/25">
                  <x.i className="h-5 w-5" />
                </span>
                <div>
                  <p className="font-semibold text-white">{x.t}</p>
                  <p className="text-sm text-slate-400">{x.d}</p>
                </div>
              </li>
            ))}
          </ul>
          <div className="mt-8 flex flex-wrap gap-x-6 gap-y-2 text-xs text-slate-400">
            <span className="inline-flex items-center gap-1.5"><ShieldCheck className="h-4 w-4 text-accent" /> NDA on request</span>
            <span className="inline-flex items-center gap-1.5"><CheckCircle2 className="h-4 w-4 text-accent" /> No obligation</span>
          </div>
        </Reveal>

        <Reveal delay={0.1}>
          <div className="rounded-2xl border border-white/10 bg-white p-6 shadow-2xl sm:p-8">
            <p className="text-lg font-bold text-navy">Request your consultation</p>
            <p className="mt-1 text-sm text-slate-500">All fields are required.</p>
            <div className="mt-6">
              <LeadForm intent="consultation" />
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
