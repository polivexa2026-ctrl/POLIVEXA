"use client";
import * as React from "react";
import { motion } from "framer-motion";
import {
  ArrowRight,
  ArrowUpRight,
  BellRing,
  Check,
  CloudCog,
  FileLock2,
  Globe2,
  Layers3,
  Map,
  MessageSquareWarning,
  Radar,
  ServerCog,
  ShieldHalf,
  UserCog,
  Workflow,
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { SectionHeading } from "@/components/section-heading";
import { useLeadModal } from "@/components/lead/lead-modal";
import { SERVICES_TAB_EVENT, type ServicesTab } from "@/lib/site";

type Service = { icon: typeof Map; title: string; desc: string; deliverables: string[]; tag?: string };

const DPDP: Service[] = [
  {
    icon: Map,
    title: "Data Mapping & Inventory (RoPA)",
    desc: "Discover every personal data element across databases, ERPs, CRMs, SaaS and shadow IT — then build a living Record of Processing Activities.",
    deliverables: ["Automated PII discovery", "Data-flow diagrams", "Purpose & retention register"],
  },
  {
    icon: Globe2,
    title: "Multilingual Notice & Consent Architecture",
    desc: "Itemised notices in English and 22 scheduled languages, with purpose-level consent capture, withdrawal and Consent Manager interoperability.",
    deliverables: ["Consent SDK / API design", "Notice templates ×23", "Withdrawal propagation"],
    tag: "Most requested",
  },
  {
    icon: MessageSquareWarning,
    title: "Data Principal Rights Portal & Grievance Redressal",
    desc: "A self-serve portal and back-office workflow for access, correction, erasure, nomination and grievances — with SLA tracking and identity verification.",
    deliverables: ["DPR portal & workflows", "Identity verification", "Grievance officer SOPs"],
  },
  {
    icon: UserCog,
    title: "SDF Readiness & Virtual DPO",
    desc: "Assess Significant Data Fiduciary exposure and operate as your outsourced DPO office — DPIAs, independent audit prep and Board-level reporting.",
    deliverables: ["SDF applicability memo", "Periodic DPIAs", "vDPO retainer"],
  },
  {
    icon: BellRing,
    title: "Breach Incident Response & 72-hr Framework",
    desc: "Playbooks that satisfy both DPDP (Board & Data Principal intimation, detailed report within 72 hours) and CERT-In’s 6-hour reporting mandate.",
    deliverables: ["IR playbooks & RACI", "Notification templates", "Tabletop mock drills"],
  },
  {
    icon: FileLock2,
    title: "Cross-border Transfers & DPAs",
    desc: "Transfer impact assessments against government restrictions and sectoral rules, plus processor contracts that flow down DPDP obligations.",
    deliverables: ["Transfer assessments", "DPA / SCC templates", "Vendor due-diligence"],
  },
];

const IT: Service[] = [
  {
    icon: CloudCog,
    title: "Secure Cloud Architecture & Zero Trust",
    desc: "Landing zones on AWS and Azure designed for data residency, least-privilege access, micro-segmentation and continuous verification.",
    deliverables: ["AWS / Azure landing zones", "Zero Trust network design", "KMS & encryption at rest"],
  },
  {
    icon: Workflow,
    title: "Enterprise System Integration & Data Governance",
    desc: "Wire consent, retention and deletion signals across ERP, CRM, data lakes and SaaS through event-driven APIs with full lineage.",
    deliverables: ["API & event mesh", "Data catalogue & lineage", "Retention automation"],
  },
  {
    icon: Radar,
    title: "Vulnerability Assessment & Penetration Testing",
    desc: "CERT-In aligned VAPT across web, mobile, APIs and cloud — with prioritised remediation and verified re-tests.",
    deliverables: ["Web / API / mobile VAPT", "Cloud config review", "Remediation re-test"],
  },
  {
    icon: Layers3,
    title: "ISO 27001 / SOC 2 / GDPR / DPDP Hybrid Alignment",
    desc: "One unified control framework mapped across standards, so every control you build satisfies multiple audits at once.",
    deliverables: ["Unified control matrix", "Policy stack", "Certification-ready evidence"],
  },
];

function ServiceCard({ s, i }: { s: Service; i: number }) {
  const { open } = useLeadModal();
  return (
    <motion.article
      initial={{ opacity: 0, y: 18 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45, delay: i * 0.06, ease: [0.22, 1, 0.36, 1] }}
      className="group relative flex flex-col overflow-hidden rounded-2xl border border-slate-200 bg-white p-6 transition-all duration-300 hover:-translate-y-1 hover:border-accent/40 hover:shadow-[0_24px_48px_-24px_rgba(10,25,47,0.25)]"
    >
      <div className="absolute inset-x-0 top-0 h-0.5 origin-left scale-x-0 bg-gradient-to-r from-accent to-emerald-500 transition-transform duration-500 group-hover:scale-x-100" />
      <div className="flex items-start justify-between">
        <span className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-navy text-accent transition group-hover:bg-accent group-hover:text-navy">
          <s.icon className="h-[22px] w-[22px]" />
        </span>
        {s.tag && (
          <span className="rounded-full bg-accent/10 px-2.5 py-1 text-[11px] font-semibold text-[#00937F] ring-1 ring-accent/30">
            {s.tag}
          </span>
        )}
      </div>
      <h3 className="mt-5 text-lg font-bold leading-snug text-navy">{s.title}</h3>
      <p className="mt-2 text-sm leading-relaxed text-slate-600">{s.desc}</p>
      <ul className="mt-5 space-y-2 border-t border-slate-100 pt-5">
        {s.deliverables.map((d) => (
          <li key={d} className="flex items-center gap-2 text-[13px] font-medium text-slate-700">
            <Check className="h-4 w-4 shrink-0 text-accent" /> {d}
          </li>
        ))}
      </ul>
      <button
        onClick={() => open({ intent: "consultation", context: { service: s.title } })}
        className="mt-auto inline-flex items-center gap-1.5 self-start pt-6 text-sm font-semibold text-navy transition hover:text-[#00937F]"
      >
        Discuss this service
        <ArrowUpRight className="h-4 w-4 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
      </button>
    </motion.article>
  );
}

export function Services() {
  const [tab, setTab] = React.useState<ServicesTab>("dpdp");
  const { open } = useLeadModal();

  React.useEffect(() => {
    const t = new URLSearchParams(window.location.search).get("tab");
    if (t === "dpdp" || t === "it") setTab(t);
  }, []);

  React.useEffect(() => {
    const handler = (e: Event) => setTab((e as CustomEvent<ServicesTab>).detail);
    window.addEventListener(SERVICES_TAB_EVENT, handler);
    return () => window.removeEventListener(SERVICES_TAB_EVENT, handler);
  }, []);

  return (
    <section id="services" className="section-pad bg-white">
      <div className="container">
        <SectionHeading
          eyebrow="Specialised services"
          title="Two tracks. One accountable partner."
          description="Engage us for DPDP compliance, enterprise IT, or both — our dual-track delivery means your privacy program and your infrastructure are designed together."
        />

        <Tabs value={tab} onValueChange={(v) => setTab(v as ServicesTab)} className="mt-12">
          <div className="flex justify-center">
            <TabsList className="grid w-full max-w-lg grid-cols-2">
              <TabsTrigger value="dpdp">
                <ShieldHalf /> <span className="sm:hidden">DPDP Consulting</span>
                <span className="hidden sm:inline">DPDP Act 2023 Consulting</span>
              </TabsTrigger>
              <TabsTrigger value="it">
                <ServerCog /> <span className="sm:hidden">IT &amp; Cloud</span>
                <span className="hidden sm:inline">IT &amp; Cloud Consulting</span>
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="dpdp">
            <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {DPDP.map((s, i) => (
                <ServiceCard key={s.title} s={s} i={i} />
              ))}
            </div>
          </TabsContent>

          <TabsContent value="it">
            <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
              {IT.map((s, i) => (
                <ServiceCard key={s.title} s={s} i={i} />
              ))}
              <motion.div
                initial={{ opacity: 0, y: 18 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.45, delay: 0.3 }}
                className="relative flex flex-col justify-between overflow-hidden rounded-2xl bg-navy-900 p-6 md:col-span-2"
              >
                <div className="absolute -right-10 -top-10 h-48 w-48 rounded-full bg-accent/20 blur-3xl" />
                <div className="relative">
                  <p className="text-xs font-semibold uppercase tracking-wider text-accent">Better together</p>
                  <h3 className="mt-3 text-xl font-bold text-white sm:text-2xl">
                    Bundle IT &amp; DPDP for a single control framework and one evidence trail.
                  </h3>
                  <p className="mt-3 max-w-lg text-sm leading-relaxed text-slate-400">
                    Clients who run both tracks together avoid duplicate audits, rework and conflicting vendor advice.
                  </p>
                </div>
                <div className="relative mt-6 flex flex-col gap-3 sm:flex-row">
                  <Button onClick={() => open({ intent: "consultation", context: { service: "Dual-track bundle" } })}>
                    Plan a dual-track engagement <ArrowRight />
                  </Button>
                  <Button variant="outline-dark" onClick={() => setTab("dpdp")}>
                    View DPDP services
                  </Button>
                </div>
              </motion.div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </section>
  );
}
