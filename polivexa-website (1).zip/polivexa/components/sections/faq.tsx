"use client";
import { MessageCircleQuestion } from "lucide-react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { SectionHeading } from "@/components/section-heading";
import { Reveal } from "@/components/motion";
import { useLeadModal } from "@/components/lead/lead-modal";

const FAQS = [
  {
    q: "What are the penalties under the DPDP Act 2023?",
    a: (
      <>
        The Schedule to the Act sets maximum penalties per instance: up to <strong>₹250 crore</strong> for failing to take
        reasonable security safeguards to prevent a personal data breach; up to <strong>₹200 crore</strong> each for failing to
        notify the Board and affected Data Principals of a breach, and for breaching obligations relating to children; up to{" "}
        <strong>₹150 crore</strong> for breaching Significant Data Fiduciary obligations; and up to <strong>₹50 crore</strong>{" "}
        for other breaches. The Data Protection Board considers the nature, gravity and duration of the breach, mitigation steps
        taken and repeat behaviour when determining the amount.
      </>
    ),
  },
  {
    q: "Who qualifies as a Data Fiduciary — and does the Act apply to companies outside India?",
    a: (
      <>
        A Data Fiduciary is any person or entity that, alone or with others, <strong>determines the purpose and means</strong> of
        processing personal data. A Data Processor processes data on its behalf. The Act covers digital personal data processed
        within India (including data collected offline and later digitised), and also processing outside India when it is
        connected to offering goods or services to Data Principals in India — so global SaaS, e-commerce and services firms with
        Indian users are generally in scope.
      </>
    ),
  },
  {
    q: "What are the obligations for children's data?",
    a: (
      <>
        Under the Act, a child is anyone under 18. Fiduciaries must obtain <strong>verifiable consent of a parent or lawful
        guardian</strong> before processing a child&apos;s data, must not undertake processing likely to cause a detrimental effect
        on a child&apos;s well-being, and must not carry out <strong>tracking, behavioural monitoring or targeted advertising</strong>{" "}
        directed at children. Similar guardian-consent requirements apply to persons with disabilities who have a lawful guardian.
        The Rules provide limited exemptions for specific classes of fiduciaries and purposes.
      </>
    ),
  },
  {
    q: "What is the timeline for DPDP compliance?",
    a: (
      <>
        The DPDP Rules, 2025 introduced a <strong>phased rollout</strong>: provisions constituting the Data Protection Board
        took effect first, Consent Manager provisions follow after roughly 12 months, and most substantive obligations — notices,
        consent, security safeguards, breach intimation, Data Principal rights and retention — apply after roughly 18 months from
        notification. Realistically, a full program (discovery, remediation and technical implementation) takes 4–9 months for a
        mid-to-large enterprise, so organisations should be well into remediation now. We&apos;ll confirm the exact dates applicable
        to you during scoping.
      </>
    ),
  },
  {
    q: "What is a Significant Data Fiduciary (SDF)?",
    a: (
      <>
        The Central Government may notify certain fiduciaries as SDFs based on factors such as the volume and sensitivity of data
        processed, risk to Data Principals, and impact on sovereignty, security or public order. SDFs must appoint an India-based
        Data Protection Officer, engage an independent data auditor, conduct periodic Data Protection Impact Assessments and meet
        additional due-diligence obligations. Our SDF Readiness and Virtual DPO services cover all of these.
      </>
    ),
  },
  {
    q: "How does Polivexa work with our existing legal and IT teams?",
    a: (
      <>
        We act as the <strong>bridge</strong>, not a replacement. Your legal counsel retains ownership of legal opinions and
        representation; we translate their positions into operational controls, and translate your technical reality back into
        defensible documentation. For IT, we embed with your engineering, security and cloud teams — delivering architecture,
        code-level integrations (consent SDKs, DPR APIs, deletion pipelines) and runbooks your team can own long-term. Engagements
        are fixed-scope with a shared RACI and weekly steering updates.
      </>
    ),
  },
  {
    q: "We're already GDPR / ISO 27001 compliant. How much of that carries over?",
    a: (
      <>
        A meaningful amount — typically security controls, vendor management and parts of the rights workflow. But DPDP differs
        in important ways: no &quot;legitimate interests&quot; basis, stricter consent and notice requirements, 22-language notice support,
        verifiable parental consent up to age 18, and India-specific breach reporting to the Board alongside CERT-In. Our hybrid
        control matrix maps what you already have, so you only build the delta.
      </>
    ),
  },
];

export function Faq() {
  const { open } = useLeadModal();
  return (
    <section id="resources" className="section-pad bg-white">
      <div className="container grid gap-12 lg:grid-cols-[0.8fr_1.2fr] lg:gap-16">
        <div className="lg:sticky lg:top-28 lg:self-start">
          <SectionHeading
            align="left"
            eyebrow="DPDP 2023 FAQ"
            title="Answers to the questions boards ask first."
            description="Plain-language guidance on India’s Digital Personal Data Protection Act. For advice specific to your organisation, talk to our team."
          />
          <Reveal delay={0.1} className="mt-8 rounded-2xl bg-navy-900 p-6">
            <MessageCircleQuestion className="h-6 w-6 text-accent" />
            <p className="mt-3 font-bold text-white">Still have questions?</p>
            <p className="mt-1 text-sm text-slate-400">A 30-minute scoping call with a DPDP specialist — no obligation.</p>
            <Button className="mt-5 w-full sm:w-auto" onClick={() => open({ intent: "consultation" })}>
              Talk to a specialist
            </Button>
          </Reveal>
        </div>

        <Reveal delay={0.1}>
          <Accordion type="single" collapsible defaultValue="item-0" className="space-y-3">
            {FAQS.map((f, i) => (
              <AccordionItem key={f.q} value={`item-${i}`}>
                <AccordionTrigger>{f.q}</AccordionTrigger>
                <AccordionContent>{f.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
          <p className="mt-6 text-xs leading-relaxed text-slate-500">
            This FAQ is general information about the DPDP Act, 2023 and DPDP Rules, 2025, and is not legal advice. Refer to the
            official Gazette notifications and consult qualified counsel for decisions specific to your organisation.
          </p>
        </Reveal>
      </div>
    </section>
  );
}
