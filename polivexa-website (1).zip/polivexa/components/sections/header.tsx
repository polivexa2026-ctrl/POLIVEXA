"use client";
import * as React from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronDown, Cloud, FileLock2, Gauge, Menu, ShieldHalf, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/logo";
import { useLeadModal } from "@/components/lead/lead-modal";
import { goToServices, type ServicesTab } from "@/lib/site";
import { cn } from "@/lib/utils";

const SOLUTIONS: { label: string; desc: string; icon: typeof FileLock2; tab: ServicesTab }[] = [
  { label: "DPDP Compliance", desc: "RoPA, consent, DPR portal, breach response & vDPO", icon: FileLock2, tab: "dpdp" },
  { label: "IT Infrastructure & Cloud", desc: "Secure AWS/Azure architecture & system integration", icon: Cloud, tab: "it" },
  { label: "Cyber Security", desc: "VAPT, Zero Trust & ISO 27001 / SOC 2 alignment", icon: ShieldHalf, tab: "it" },
];

const LINKS = [
  { label: "Compliance Platform", href: "/#platform" },
  { label: "Enterprise Assessment", href: "/#assessment" },
  { label: "About Us", href: "/about" },
  { label: "Resources", href: "/#resources" },
];

export function Header() {
  const { open } = useLeadModal();
  const [scrolled, setScrolled] = React.useState(false);
  const [menuOpen, setMenuOpen] = React.useState(false);
  const [solOpen, setSolOpen] = React.useState(false);
  const [mobileSolOpen, setMobileSolOpen] = React.useState(true);
  const closeTimer = React.useRef<ReturnType<typeof setTimeout>>();

  React.useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  React.useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [menuOpen]);

  const openSol = () => {
    clearTimeout(closeTimer.current);
    setSolOpen(true);
  };
  const closeSol = () => {
    closeTimer.current = setTimeout(() => setSolOpen(false), 120);
  };

  return (
    <header
      className={cn(
        "fixed inset-x-0 top-0 z-40 transition-all duration-300",
        scrolled || menuOpen
          ? "border-b border-white/10 bg-navy-900/95 shadow-[0_10px_30px_-15px_rgba(0,0,0,0.6)] backdrop-blur-xl"
          : "border-b border-transparent bg-transparent"
      )}
    >
      <div className="container flex h-[72px] items-center justify-between gap-6">
        <a href="/" aria-label="POLIVEXA home" className="shrink-0">
          <Logo />
        </a>

        {/* Desktop nav */}
        <nav className="hidden items-center gap-1 lg:flex" aria-label="Primary">
          <div className="relative" onMouseEnter={openSol} onMouseLeave={closeSol}>
            <button
              className="inline-flex items-center gap-1 rounded-md px-3 py-2 text-sm font-medium text-slate-300 transition hover:text-white"
              aria-expanded={solOpen}
              aria-haspopup="true"
              onClick={() => setSolOpen((v) => !v)}
            >
              Solutions
              <ChevronDown className={cn("h-4 w-4 transition-transform", solOpen && "rotate-180")} />
            </button>
            <AnimatePresence>
              {solOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 8 }}
                  transition={{ duration: 0.18 }}
                  className="absolute left-1/2 top-full w-[380px] -translate-x-1/2 pt-3"
                >
                  <div className="rounded-2xl border border-white/10 bg-navy-800/95 p-2 shadow-2xl backdrop-blur-xl">
                    {SOLUTIONS.map((s) => (
                      <button
                        key={s.label}
                        onClick={() => {
                          setSolOpen(false);
                          goToServices(s.tab);
                        }}
                        className="group flex w-full items-start gap-3 rounded-xl p-3 text-left transition hover:bg-white/5"
                      >
                        <span className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-accent/10 text-accent ring-1 ring-accent/20 transition group-hover:bg-accent group-hover:text-navy">
                          <s.icon className="h-[18px] w-[18px]" />
                        </span>
                        <span>
                          <span className="block text-sm font-semibold text-white">{s.label}</span>
                          <span className="mt-0.5 block text-xs leading-snug text-slate-400">{s.desc}</span>
                        </span>
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
          {LINKS.map((l) => (
            <a
              key={l.label}
              href={l.href}
              className="rounded-md px-3 py-2 text-sm font-medium text-slate-300 transition hover:text-white"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-2.5 lg:flex">
          <Button variant="outline-dark" size="sm" asChild>
            <a href="/#assessment">
              <Gauge /> DPDP Readiness Scorecard
            </a>
          </Button>
          <Button size="sm" onClick={() => open({ intent: "consultation" })}>
            Book Consultation
          </Button>
        </div>

        <button
          className="inline-flex h-10 w-10 items-center justify-center rounded-lg text-white ring-1 ring-white/15 lg:hidden"
          aria-label={menuOpen ? "Close menu" : "Open menu"}
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((v) => !v)}
        >
          {menuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "calc(100dvh - 72px)" }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-y-auto border-t border-white/10 bg-navy-900 lg:hidden"
          >
            <nav className="container flex flex-col gap-1 py-5" aria-label="Mobile">
              <button
                className="flex items-center justify-between rounded-lg px-3 py-3 text-base font-semibold text-white"
                onClick={() => setMobileSolOpen((v) => !v)}
                aria-expanded={mobileSolOpen}
              >
                Solutions <ChevronDown className={cn("h-5 w-5 transition-transform", mobileSolOpen && "rotate-180")} />
              </button>
              {mobileSolOpen && (
                <div className="mb-2 grid gap-1 pl-2">
                  {SOLUTIONS.map((s) => (
                    <button
                      key={s.label}
                      onClick={() => {
                        setMenuOpen(false);
                        setTimeout(() => goToServices(s.tab), 50);
                      }}
                      className="flex items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm text-slate-300 hover:bg-white/5"
                    >
                      <s.icon className="h-4 w-4 text-accent" /> {s.label}
                    </button>
                  ))}
                </div>
              )}
              {LINKS.map((l) => (
                <a
                  key={l.label}
                  href={l.href}
                  onClick={() => setMenuOpen(false)}
                  className="rounded-lg px-3 py-3 text-base font-semibold text-white hover:bg-white/5"
                >
                  {l.label}
                </a>
              ))}
              <div className="mt-5 grid gap-3">
                <Button variant="outline-dark" size="lg" asChild>
                  <a href="/#assessment" onClick={() => setMenuOpen(false)}>
                    <Gauge /> DPDP Readiness Scorecard
                  </a>
                </Button>
                <Button
                  size="lg"
                  onClick={() => {
                    setMenuOpen(false);
                    open({ intent: "consultation" });
                  }}
                >
                  Book Consultation
                </Button>
              </div>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
