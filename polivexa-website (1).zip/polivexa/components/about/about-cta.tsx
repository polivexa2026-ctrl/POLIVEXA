"use client";
import { ArrowRight, CalendarCheck, ShieldHalf } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Reveal } from "@/components/motion";
import { useLeadModal } from "@/components/lead/lead-modal";
import { goToServices } from "@/lib/site";

export function AboutCta() {
  const { open } = useLeadModal();
  return (
    <section className="bg-white pb-20 sm:pb-24 lg:pb-28">
      <div className="container">
        <Reveal className="relative overflow-hidden rounded-3xl bg-navy-900 px-6 py-14 text-center sm:px-12 sm:py-20">
          <div className="absolute inset-0 bg-grid-light bg-[size:48px_48px] [mask-image:radial-gradient(ellipse_70%_70%_at_50%_50%,black,transparent)]" />
          <div className="absolute left-1/2 top-0 h-64 w-[640px] -translate-x-1/2 rounded-full bg-accent/20 blur-[100px]" />
          <div className="relative mx-auto max-w-3xl">
            <h2 className="text-balance text-3xl font-extrabold leading-tight tracking-[-0.012em] text-white sm:text-4xl lg:text-[44px]">
              Ready to align your enterprise with India&apos;s evolving{" "}
              <span className="text-gradient">digital governance</span> landscape?
            </h2>
            <p className="mx-auto mt-5 max-w-xl text-base leading-relaxed text-slate-300 sm:text-lg">
              Start with a conversation with our leadership team. We&apos;ll map where you stand and what it takes to get audit-ready.
            </p>
            <div className="mt-9 flex flex-col justify-center gap-3 sm:flex-row">
              <Button size="lg" onClick={() => open({ intent: "consultation", context: { source: "about-page", request: "Speak with leadership" } })}>
                <CalendarCheck /> Speak with Our Leadership
                <ArrowRight className="transition-transform group-hover:translate-x-0.5" />
              </Button>
              <Button size="lg" variant="outline-dark" onClick={() => goToServices("dpdp")}>
                <ShieldHalf /> Explore DPDP Solutions
              </Button>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
