"use client";
import { motion } from "framer-motion";
import { ArrowRight, Code2, FileCheck2, Landmark, ScrollText, ServerCog, ShieldCheck, Users } from "lucide-react";
import { Reveal } from "@/components/motion";

const FLOW = [
  { icon: Landmark, label: "Board decision" },
  { icon: ScrollText, label: "Policy" },
  { icon: ShieldCheck, label: "Control" },
  { icon: Code2, label: "Production code" },
  { icon: FileCheck2, label: "Audit evidence" },
];

export function Governance() {
  return (
    <section className="section-pad bg-white">
      <div className="container">
        <Reveal className="mx-auto max-w-2xl text-center">
          <span className="eyebrow border-accent/30 bg-accent/10 text-[#00937F]">
            <span className="h-1.5 w-1.5 rounded-full bg-accent" /> Advisory &amp; governance philosophy
          </span>
          <h2 className="mt-5 text-balance text-3xl font-extrabold leading-[1.12] tracking-[-0.012em] text-navy sm:text-4xl">
            Governance that reaches all the way to the code.
          </h2>
        </Reveal>

        <div className="mt-12 grid gap-px overflow-hidden rounded-2xl border border-slate-200 bg-slate-200 md:grid-cols-2">
          {[
            {
              icon: Users,
              title: "Multi-Disciplinary Board",
              desc: "Combining legislative insights, legal clarity, and hands-on systems architecture — so policy positions are always technically achievable.",
            },
            {
              icon: ServerCog,
              title: "Audit-Ready Infrastructure",
              desc: "From board-level decisions to production code implementation — every control is traceable, tested, and backed by evidence.",
            },
          ].map((x, i) => (
            <Reveal key={x.title} delay={i * 0.1} className="group bg-white p-7 transition-colors hover:bg-slate-50 sm:p-10">
              <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-navy text-accent transition group-hover:bg-accent group-hover:text-navy">
                <x.icon className="h-[22px] w-[22px]" />
              </span>
              <h3 className="mt-5 text-xl font-bold text-navy">{x.title}</h3>
              <p className="mt-2 max-w-md text-[15px] leading-relaxed text-slate-600">{x.desc}</p>
            </Reveal>
          ))}
        </div>

        {/* Traceability flow */}
        <Reveal delay={0.15} className="mt-8">
          <ol className="flex flex-col items-stretch gap-2 sm:flex-row sm:items-center sm:justify-between">
            {FLOW.map((f, i) => (
              <li key={f.label} className="flex items-center gap-2 sm:flex-1">
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.2 + i * 0.12 }}
                  className="flex flex-1 items-center gap-2.5 rounded-xl border border-slate-200 bg-slate-50 px-3.5 py-3 text-sm font-semibold text-navy"
                >
                  <f.icon className="h-4 w-4 shrink-0 text-[#00A58D]" />
                  {f.label}
                </motion.div>
                {i < FLOW.length - 1 && <ArrowRight className="hidden h-4 w-4 shrink-0 text-accent sm:block" />}
              </li>
            ))}
          </ol>
        </Reveal>
      </div>
    </section>
  );
}
