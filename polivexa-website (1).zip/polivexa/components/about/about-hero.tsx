"use client";
import { motion } from "framer-motion";
import { ChevronRight, Compass, Cpu, Eye, Gauge, Home, Landmark, Scale, Target } from "lucide-react";
import { Stagger, StaggerItem } from "@/components/motion";

const VALUES = [
  { icon: Scale, title: "Integrity", desc: "Candid advice, even when it’s inconvenient. We never overstate compliance." },
  { icon: Cpu, title: "Engineering Precision", desc: "Every obligation becomes a testable control, shipped and evidenced." },
  { icon: Gauge, title: "Regulatory Agility", desc: "We track Rules, Board orders and CERT-In directions as they evolve." },
  { icon: Landmark, title: "Public Accountability", desc: "Privacy is a citizen right. We design for the Data Principal first." },
];

export function AboutHero() {
  return (
    <section className="relative isolate overflow-hidden bg-navy-900 pt-[72px]">
      <div className="absolute inset-0 -z-10 bg-grid-light bg-[size:56px_56px] [mask-image:radial-gradient(ellipse_80%_60%_at_50%_20%,black,transparent)]" />
      <div className="absolute -top-40 left-1/2 -z-10 h-[480px] w-[860px] -translate-x-1/2 rounded-full bg-accent/15 blur-[120px]" />

      <div className="container pb-20 pt-10 sm:pt-14 lg:pb-28">
        {/* Breadcrumb */}
        <motion.nav
          aria-label="Breadcrumb"
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <ol className="flex items-center gap-1.5 text-sm text-slate-400">
            <li>
              <a href="/" className="inline-flex items-center gap-1.5 transition hover:text-white">
                <Home className="h-3.5 w-3.5" /> Home
              </a>
            </li>
            <li aria-hidden="true">
              <ChevronRight className="h-3.5 w-3.5 text-slate-600" />
            </li>
            <li aria-current="page" className="font-semibold text-accent">
              About Us
            </li>
          </ol>
        </motion.nav>

        <div className="mt-10 max-w-3xl">
          <motion.span
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.05 }}
            className="eyebrow border-accent/30 bg-accent/10 text-accent"
          >
            <span className="h-1.5 w-1.5 rounded-full bg-accent" /> About POLIVEXA
          </motion.span>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1, ease: [0.22, 1, 0.36, 1] }}
            className="mt-6 text-balance text-[34px] font-extrabold leading-[1.08] tracking-[-0.012em] text-white sm:text-5xl lg:text-[58px]"
          >
            Pioneering <span className="text-gradient">Trust, Privacy</span> &amp; Enterprise Technology
          </motion.h1>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.18, ease: [0.22, 1, 0.36, 1] }}
            className="mt-6 max-w-2xl text-pretty text-base leading-relaxed text-slate-300 sm:text-lg"
          >
            Bridging the critical gap between complex regulatory mandates like the DPDP Act 2023 and scalable, modern cloud &amp;
            IT architecture.
          </motion.p>
        </div>

        {/* Vision & Mission bento */}
        <Stagger className="mt-14 grid gap-4 sm:gap-5 lg:grid-cols-3">
          <StaggerItem className="glass group relative overflow-hidden rounded-2xl p-6 sm:p-8 lg:col-span-2">
            <div className="absolute -right-16 -top-16 h-56 w-56 rounded-full bg-accent/15 blur-3xl transition-opacity duration-500 group-hover:opacity-100 lg:opacity-60" />
            <div className="relative">
              <div className="flex items-center gap-3">
                <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-accent text-navy">
                  <Target className="h-5 w-5" />
                </span>
                <p className="text-xs font-bold uppercase tracking-[0.16em] text-accent">Our Mission</p>
              </div>
              <p className="mt-6 text-balance text-xl font-semibold leading-snug text-white sm:text-2xl lg:text-[28px]">
                Enabling digital fiduciaries and enterprises across India and globally to achieve{" "}
                <span className="text-gradient">provable, frictionless</span> data privacy compliance.
              </p>
            </div>
          </StaggerItem>

          <StaggerItem className="glass group relative overflow-hidden rounded-2xl p-6 sm:p-8">
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/5 text-accent ring-1 ring-white/15">
                <Eye className="h-5 w-5" />
              </span>
              <p className="text-xs font-bold uppercase tracking-[0.16em] text-accent">Our Vision</p>
            </div>
            <p className="mt-6 text-lg font-semibold leading-snug text-white sm:text-xl">
              Becoming the premier authority where legal governance meets technical engineering.
            </p>
          </StaggerItem>

          <StaggerItem className="glass rounded-2xl p-6 sm:p-8 lg:col-span-3">
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-white/5 text-accent ring-1 ring-white/15">
                <Compass className="h-5 w-5" />
              </span>
              <p className="text-xs font-bold uppercase tracking-[0.16em] text-accent">Core Values</p>
            </div>
            <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {VALUES.map((v) => (
                <div
                  key={v.title}
                  className="group rounded-xl border border-white/10 bg-white/[0.03] p-5 transition hover:-translate-y-0.5 hover:border-accent/40 hover:bg-white/[0.06]"
                >
                  <v.icon className="h-5 w-5 text-accent transition group-hover:scale-110" />
                  <p className="mt-3 font-bold text-white">{v.title}</p>
                  <p className="mt-1.5 text-sm leading-relaxed text-slate-400">{v.desc}</p>
                </div>
              ))}
            </div>
          </StaggerItem>
        </Stagger>
      </div>
    </section>
  );
}
