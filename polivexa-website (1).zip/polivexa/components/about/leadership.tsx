"use client";
import Image from "next/image";
import { Award, BookOpen, Briefcase, GraduationCap, Landmark, Linkedin, Mail, Sparkles, Twitter } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SectionHeading } from "@/components/section-heading";
import { Stagger, StaggerItem } from "@/components/motion";
import { LogoMark } from "@/components/logo";
import type { Accolade, TeamMember } from "@/lib/team";
import { cn } from "@/lib/utils";

const ACCOLADE_ICON: Record<Accolade["kind"], typeof Award> = {
  award: Award,
  book: BookOpen,
  degree: GraduationCap,
  experience: Briefcase,
  policy: Landmark,
};

function initials(name: string) {
  const parts = name.split(" ").filter(Boolean);
  return (parts[0][0] + (parts.length > 1 ? parts[parts.length - 1][0] : "")).toUpperCase();
}

/** Portrait with hover zoom. Falls back to a branded monogram until the photo file exists. */
function Portrait({ member, hasImage, className, sizes }: { member: TeamMember; hasImage: boolean; className?: string; sizes: string }) {
  return (
    <div className={cn("relative overflow-hidden rounded-xl bg-navy-800", className)}>
      {hasImage ? (
        <Image
          src={member.image}
          alt={`Portrait of ${member.name}, ${member.role} at POLIVEXA`}
          fill
          sizes={sizes}
          className="object-cover transition-transform duration-700 ease-out group-hover:scale-[1.06]"
        />
      ) : (
        <div
          role="img"
          aria-label={`Portrait placeholder for ${member.name}, ${member.role} at POLIVEXA`}
          className="absolute inset-0 flex items-center justify-center bg-[radial-gradient(circle_at_30%_20%,rgba(0,210,180,0.22),transparent_55%),linear-gradient(160deg,#112240,#0A192F_60%,#050D1A)] transition-transform duration-700 ease-out group-hover:scale-[1.06]"
        >
          <div className="absolute inset-0 bg-grid-light bg-[size:28px_28px] opacity-70" />
          <span className="text-gradient relative text-6xl font-extrabold tracking-wide sm:text-7xl">{initials(member.name)}</span>
          <LogoMark className="absolute bottom-4 right-4 h-7 w-7 opacity-40" />
        </div>
      )}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-1/3 bg-gradient-to-t from-navy-950/50 to-transparent" />
    </div>
  );
}

function Socials({ member, dark = false }: { member: TeamMember; dark?: boolean }) {
  const items = [
    { icon: Linkedin, label: "LinkedIn", href: member.linkedin },
    { icon: Twitter, label: "X (Twitter)", href: member.x },
    { icon: Mail, label: "Email", href: member.email ? `mailto:${member.email}` : "" },
  ];
  return (
    <div className="flex gap-2">
      {items.map((s) =>
        s.href ? (
          <a
            key={s.label}
            href={s.href}
            target={s.href.startsWith("http") ? "_blank" : undefined}
            rel="noopener noreferrer"
            aria-label={`${member.name} on ${s.label}`}
            className={cn(
              "flex h-9 w-9 items-center justify-center rounded-lg ring-1 transition hover:-translate-y-0.5 hover:bg-accent hover:text-navy hover:ring-accent",
              dark ? "bg-white/5 text-slate-300 ring-white/10" : "bg-slate-50 text-slate-500 ring-slate-200"
            )}
          >
            <s.icon className="h-4 w-4" />
          </a>
        ) : (
          <span
            key={s.label}
            title={`${s.label} link coming soon`}
            aria-hidden="true"
            className={cn(
              "flex h-9 w-9 items-center justify-center rounded-lg ring-1",
              dark ? "bg-white/[0.03] text-slate-600 ring-white/5" : "bg-slate-50 text-slate-300 ring-slate-100"
            )}
          >
            <s.icon className="h-4 w-4" />
          </span>
        )
      )}
    </div>
  );
}

function FeaturedCard({ member, hasImage }: { member: TeamMember; hasImage: boolean }) {
  return (
    <Card className="group relative h-full overflow-hidden border-navy-700 bg-navy-900 p-3 text-white transition-all duration-300 hover:-translate-y-1 hover:shadow-[0_30px_60px_-30px_rgba(0,210,180,0.45)]">
      <div className="absolute -right-24 -top-24 h-72 w-72 rounded-full bg-accent/15 blur-3xl" />
      <div className="relative grid h-full gap-5 sm:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)]">
        <Portrait
          member={member}
          hasImage={hasImage}
          sizes="(min-width: 1024px) 360px, (min-width: 640px) 45vw, 100vw"
          className="aspect-[4/5] sm:aspect-auto sm:h-full sm:min-h-[440px]"
        />
        <div className="flex flex-col px-3 pb-4 sm:px-2 sm:py-5 sm:pr-5">
          <span className="inline-flex items-center gap-1.5 self-start rounded-full bg-accent px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider text-navy">
            <Sparkles className="h-3.5 w-3.5" /> Leadership Spotlight
          </span>
          <h3 className="mt-4 text-2xl font-extrabold tracking-[-0.012em] sm:text-3xl">{member.name}</h3>
          <Badge variant="dark" className="mt-2.5 self-start">{member.role}</Badge>

          <ul className="mt-5 space-y-2">
            {member.credential.map((c) => {
              const Icon = ACCOLADE_ICON[c.kind];
              return (
                <li key={c.label} className="flex items-center gap-2.5 rounded-lg bg-white/[0.04] px-3 py-2 text-[13px] font-semibold text-slate-200 ring-1 ring-white/10">
                  <Icon className="h-4 w-4 shrink-0 text-accent" /> {c.label}
                </li>
              );
            })}
          </ul>

          <p className="mt-5 text-sm leading-relaxed text-slate-300">{member.bio}</p>
          <div className="mt-auto pt-6">
            <Socials member={member} dark />
          </div>
        </div>
      </div>
    </Card>
  );
}

function ProfileCard({ member, hasImage }: { member: TeamMember; hasImage: boolean }) {
  return (
    <Card className="group flex h-full flex-col p-3 transition-all duration-300 hover:-translate-y-1 hover:border-accent/40 hover:shadow-[0_24px_48px_-24px_rgba(10,25,47,0.3)]">
      <Portrait member={member} hasImage={hasImage} sizes="(min-width: 1024px) 380px, (min-width: 768px) 45vw, 100vw" className="aspect-[4/5]" />
      <div className="flex flex-1 flex-col px-3 pb-3 pt-5">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-xl font-bold tracking-[-0.012em] text-navy">{member.name}</h3>
          <Badge>{member.role}</Badge>
        </div>
        <div className="mt-3 flex flex-wrap gap-2">
          {member.credential.map((c) => {
            const Icon = ACCOLADE_ICON[c.kind];
            return (
              <span key={c.label} className="inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold text-slate-700 ring-1 ring-slate-200">
                <Icon className="h-3.5 w-3.5 text-[#00A58D]" /> {c.label}
              </span>
            );
          })}
        </div>
        <p className="mt-4 text-sm leading-relaxed text-slate-600">{member.bio}</p>
        <div className="mt-auto border-t border-slate-100 pt-5">
          <Socials member={member} />
        </div>
      </div>
    </Card>
  );
}

export function Leadership({ team, images }: { team: TeamMember[]; images: Record<string, boolean> }) {
  return (
    <section id="leadership" className="section-pad relative bg-slate-50">
      <div className="absolute inset-0 bg-grid-dark bg-[size:48px_48px] [mask-image:linear-gradient(to_bottom,black,transparent_40%)]" />
      <div className="container relative">
        <SectionHeading
          eyebrow="Leadership & core team"
          title="Meet Our Leadership"
          description="A multidimensional board combining governance, public policy, technology innovation, and decades of industry advisory."
        />

        <Stagger className="mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-3 lg:gap-6">
          {team.map((m) =>
            m.featured ? (
              <StaggerItem key={m.slug} className="md:col-span-2">
                <FeaturedCard member={m} hasImage={images[m.slug]} />
              </StaggerItem>
            ) : (
              <StaggerItem key={m.slug}>
                <ProfileCard member={m} hasImage={images[m.slug]} />
              </StaggerItem>
            )
          )}
        </Stagger>
      </div>
    </section>
  );
}
