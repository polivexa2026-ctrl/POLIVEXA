import { ArrowLeft } from "lucide-react";
import { Logo } from "@/components/logo";
import { Footer } from "@/components/sections/footer";

export function LegalShell({ title, updated, children }: { title: string; updated: string; children: React.ReactNode }) {
  return (
    <>
      <header className="bg-navy-900">
        <div className="container flex h-[72px] items-center justify-between">
          <a href="/" aria-label="POLIVEXA home"><Logo /></a>
          <a href="/" className="inline-flex items-center gap-1.5 text-sm font-medium text-slate-300 hover:text-white">
            <ArrowLeft className="h-4 w-4" /> Back to home
          </a>
        </div>
      </header>
      <main id="main" className="bg-white">
        <div className="container max-w-3xl py-16 sm:py-20">
          <h1 className="text-3xl font-extrabold tracking-[-0.012em] text-navy sm:text-4xl">{title}</h1>
          <p className="mt-2 text-sm text-slate-500">Last updated: {updated}</p>
          <div className="mt-6 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800">
            Template content — review with qualified counsel before publishing.
          </div>
          <div className="prose-legal mt-10 space-y-6 text-[15px] leading-relaxed text-slate-700 [&_h2]:mt-10 [&_h2]:text-xl [&_h2]:font-bold [&_h2]:text-navy [&_li]:ml-5 [&_li]:list-disc">
            {children}
          </div>
        </div>
      </main>
      <Footer />
    </>
  );
}
