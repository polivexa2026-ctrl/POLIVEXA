import { cn } from "@/lib/utils";
import { Reveal } from "@/components/motion";

export function SectionHeading({
  eyebrow,
  title,
  description,
  dark = false,
  align = "center",
  className,
}: {
  eyebrow: string;
  title: React.ReactNode;
  description?: React.ReactNode;
  dark?: boolean;
  align?: "center" | "left";
  className?: string;
}) {
  return (
    <Reveal className={cn("max-w-3xl", align === "center" && "mx-auto text-center", className)}>
      <span
        className={cn(
          "eyebrow",
          dark ? "border-accent/30 bg-accent/10 text-accent" : "border-accent/30 bg-accent/10 text-[#00937F]"
        )}
      >
        <span className="h-1.5 w-1.5 rounded-full bg-accent" />
        {eyebrow}
      </span>
      <h2
        className={cn(
          "mt-5 text-balance text-3xl font-extrabold leading-[1.12] tracking-[-0.012em] sm:text-4xl lg:text-[44px]",
          dark ? "text-white" : "text-navy"
        )}
      >
        {title}
      </h2>
      {description && (
        <p className={cn("mt-5 text-pretty text-base leading-relaxed sm:text-lg", dark ? "text-slate-300" : "text-slate-600")}>
          {description}
        </p>
      )}
    </Reveal>
  );
}
