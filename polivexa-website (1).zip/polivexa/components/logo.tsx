import { cn } from "@/lib/utils";

export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" fill="none" aria-hidden="true" className={cn("h-9 w-9", className)}>
      <defs>
        <linearGradient id="pv-g" x1="6" y1="3" x2="34" y2="37" gradientUnits="userSpaceOnUse">
          <stop stopColor="#00D2B4" />
          <stop offset="1" stopColor="#10B981" />
        </linearGradient>
      </defs>
      {/* Shield */}
      <path
        d="M20 2.5 34.5 8v11.2c0 8.9-6 15.8-14.5 18.3C11.5 35 5.5 28.1 5.5 19.2V8L20 2.5Z"
        fill="url(#pv-g)"
        fillOpacity="0.14"
        stroke="url(#pv-g)"
        strokeWidth="1.6"
        strokeLinejoin="round"
      />
      {/* Node network */}
      <path d="M13.5 14.5 20 11l6.5 3.5M13.5 14.5V22l6.5 5 6.5-5v-7.5M20 11v8.2m0 0-6.5 2.8m6.5-2.8 6.5 2.8M20 19.2V27" stroke="url(#pv-g)" strokeWidth="1.4" strokeLinecap="round" />
      <circle cx="20" cy="11" r="2" fill="#00D2B4" />
      <circle cx="13.5" cy="14.5" r="1.7" fill="#00D2B4" />
      <circle cx="26.5" cy="14.5" r="1.7" fill="#00D2B4" />
      <circle cx="20" cy="19.2" r="2.3" fill="#10B981" />
      <circle cx="13.5" cy="22" r="1.7" fill="#10B981" />
      <circle cx="26.5" cy="22" r="1.7" fill="#10B981" />
      <circle cx="20" cy="27" r="1.9" fill="#10B981" />
    </svg>
  );
}

export function Logo({ className, dark = true }: { className?: string; dark?: boolean }) {
  return (
    <span className={cn("inline-flex items-center gap-2.5", className)}>
      <LogoMark />
      <span className={cn("text-[19px] font-extrabold tracking-[0.12em]", dark ? "text-white" : "text-navy")}>
        POLIVEXA
      </span>
    </span>
  );
}
