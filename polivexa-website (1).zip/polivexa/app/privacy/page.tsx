import type { Metadata } from "next";
import { LegalShell } from "@/components/legal/legal-shell";
import { site } from "@/lib/site";

export const metadata: Metadata = { title: "Privacy Policy" };

export default function PrivacyPage() {
  return (
    <LegalShell title="Privacy Policy" updated="28 September 2026">
      <p>
        This notice explains how POLIVEXA (&quot;we&quot;, &quot;us&quot;) processes your personal data as a Data Fiduciary under the
        Digital Personal Data Protection Act, 2023 when you visit {site.domain} or contact us.
      </p>
      <h2>1. Personal data we collect</h2>
      <ul>
        <li>Contact details you submit: name, work email, company name, industry, cloud platform and DPDP preparedness stage.</li>
        <li>Readiness scorecard answers, only when you request a gap assessment.</li>
        <li>Essential technical data (e.g. IP address, browser type) needed to operate and secure the website.</li>
      </ul>
      <h2>2. Purpose of processing</h2>
      <p>We process this data solely to respond to your enquiry, prepare requested assessments and schedule consultations.</p>
      <h2>3. Consent and withdrawal</h2>
      <p>
        We process your data on the basis of your consent, given through the form checkbox. You may withdraw consent at any time by
        writing to {site.dpoEmail}; withdrawal is as easy as giving consent and does not affect processing already carried out.
      </p>
      <h2>4. Your rights as a Data Principal</h2>
      <ul>
        <li>Access a summary of personal data we process and the processing activities.</li>
        <li>Correction, completion, updating and erasure of your personal data.</li>
        <li>Grievance redressal and nomination of another individual to exercise your rights.</li>
      </ul>
      <h2>5. Retention</h2>
      <p>We retain enquiry data only as long as necessary for the stated purpose, after which it is erased.</p>
      <h2 id="cookies">6. Cookies</h2>
      <p>We use only strictly necessary cookies unless you opt in to analytics.</p>
      <h2>7. Grievance Redressal Officer</h2>
      <p>
        Email <a className="font-semibold text-[#00937F]" href={`mailto:${site.grievanceEmail}`}>{site.grievanceEmail}</a>. If
        your grievance is not resolved, you may approach the Data Protection Board of India.
      </p>
    </LegalShell>
  );
}
