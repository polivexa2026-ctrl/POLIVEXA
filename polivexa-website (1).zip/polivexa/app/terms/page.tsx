import type { Metadata } from "next";
import { LegalShell } from "@/components/legal/legal-shell";
import { site } from "@/lib/site";

export const metadata: Metadata = { title: "Terms of Service" };

export default function TermsPage() {
  return (
    <LegalShell title="Terms of Service" updated="28 September 2026">
      <p>By accessing {site.domain} you agree to these terms.</p>
      <h2>1. Nature of services</h2>
      <p>
        POLIVEXA provides technology and compliance consulting services. POLIVEXA is not a law firm and does not provide legal
        representation or legal opinions. Content on this website is general information and not legal advice.
      </p>
      <h2>2. Readiness tools</h2>
      <p>
        The DPDP Readiness Scorecard produces an indicative score based on limited self-reported inputs. It is not an audit,
        certification or legal determination of compliance.
      </p>
      <h2>3. Intellectual property</h2>
      <p>All website content, marks and materials are owned by POLIVEXA or its licensors and may not be reproduced without consent.</p>
      <h2>4. Limitation of liability</h2>
      <p>To the maximum extent permitted by law, POLIVEXA is not liable for decisions made solely on the basis of website content.</p>
      <h2>5. Governing law</h2>
      <p>These terms are governed by the laws of India.</p>
      <h2>6. Contact</h2>
      <p>Questions? Write to <a className="font-semibold text-[#00937F]" href={`mailto:${site.email}`}>{site.email}</a>.</p>
    </LegalShell>
  );
}
