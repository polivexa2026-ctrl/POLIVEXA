import type { Metadata, Viewport } from "next";
import "@fontsource-variable/plus-jakarta-sans";
import "./globals.css";
import { LeadModalProvider } from "@/components/lead/lead-modal";
import { site } from "@/lib/site";

export const metadata: Metadata = {
  metadataBase: new URL(site.url),
  title: {
    default: "POLIVEXA — DPDP Act 2023 Compliance & Enterprise IT Consulting",
    template: "%s · POLIVEXA",
  },
  description:
    "End-to-end DPDP Act 2023 compliance and enterprise IT transformation. Consent orchestration, Data Principal rights, breach response, secure cloud architecture, VAPT and ISO 27001 alignment for Indian and global enterprises.",
  keywords: [
    "DPDP Act 2023",
    "DPDP compliance consulting",
    "DPDP Rules 2025",
    "consent management India",
    "Data Protection Board of India",
    "virtual DPO India",
    "ISO 27001 consulting",
    "VAPT India",
    "cloud security consulting",
  ],
  alternates: { canonical: "/" },
  openGraph: {
    type: "website",
    url: site.url,
    siteName: "POLIVEXA",
    title: "POLIVEXA — DPDP Act 2023 Compliance & Enterprise IT Transformation",
    description:
      "Bridge Indian legal compliance and technical execution — from consent orchestration to audit-ready cloud architecture.",
    locale: "en_IN",
  },
  twitter: {
    card: "summary_large_image",
    title: "POLIVEXA — DPDP Compliance & Enterprise IT",
    description: "End-to-end DPDP Act 2023 compliance and enterprise IT transformation.",
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: "#0A192F",
  width: "device-width",
  initialScale: 1,
};

const jsonLd = {
  "@context": "https://schema.org",
  "@type": "ProfessionalService",
  name: "POLIVEXA",
  url: site.url,
  email: site.email,
  areaServed: ["IN", "Worldwide"],
  description: "DPDP Act 2023 compliance consulting and enterprise IT consulting.",
  serviceType: ["DPDP Act 2023 Compliance Consulting", "IT & Cloud Consulting", "Cyber Security Consulting"],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en-IN">
      <body>
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[100] focus:rounded-lg focus:bg-accent focus:px-4 focus:py-2 focus:font-semibold focus:text-navy"
        >
          Skip to content
        </a>
        <LeadModalProvider>{children}</LeadModalProvider>
      </body>
    </html>
  );
}
