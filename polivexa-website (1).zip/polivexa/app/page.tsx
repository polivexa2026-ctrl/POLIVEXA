import { Header } from "@/components/sections/header";
import { Hero } from "@/components/sections/hero";
import { WhyPolivexa } from "@/components/sections/why-polivexa";
import { Services } from "@/components/sections/services";
import { ReadinessCalculator } from "@/components/sections/readiness-calculator";
import { Framework } from "@/components/sections/framework";
import { Trust } from "@/components/sections/trust";
import { Faq } from "@/components/sections/faq";
import { Contact } from "@/components/sections/contact";
import { Footer } from "@/components/sections/footer";

export default function HomePage() {
  return (
    <>
      <Header />
      <main id="main">
        <Hero />
        <WhyPolivexa />
        <Services />
        <ReadinessCalculator />
        <Framework />
        <Trust />
        <Faq />
        <Contact />
      </main>
      <Footer />
    </>
  );
}
