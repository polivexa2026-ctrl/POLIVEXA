import fs from "node:fs";
import path from "node:path";
import type { Metadata } from "next";
import { Header } from "@/components/sections/header";
import { Footer } from "@/components/sections/footer";
import { AboutHero } from "@/components/about/about-hero";
import { Leadership } from "@/components/about/leadership";
import { Governance } from "@/components/about/governance";
import { AboutCta } from "@/components/about/about-cta";
import { TEAM } from "@/lib/team";
import { site } from "@/lib/site";

export const metadata: Metadata = {
  title: "About Us — Leadership & Mission",
  description:
    "Meet POLIVEXA's leadership: a multidisciplinary board combining governance, public policy, technology innovation and industry advisory to bridge DPDP Act 2023 compliance and enterprise IT.",
  alternates: { canonical: "/about" },
  openGraph: {
    title: "About POLIVEXA — Pioneering Trust, Privacy & Enterprise Technology",
    description: "Bridging regulatory mandates like the DPDP Act 2023 with scalable, modern cloud & IT architecture.",
    url: `${site.url}/about`,
  },
};

/** Resolved at build time: show a photo only if the file is present in /public. */
function imageAvailability() {
  return Object.fromEntries(
    TEAM.map((m) => [m.slug, fs.existsSync(path.join(process.cwd(), "public", m.image.replace(/^\//, "")))])
  );
}

const jsonLd = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "BreadcrumbList",
      itemListElement: [
        { "@type": "ListItem", position: 1, name: "Home", item: site.url },
        { "@type": "ListItem", position: 2, name: "About Us", item: `${site.url}/about` },
      ],
    },
    {
      "@type": "Organization",
      name: "POLIVEXA",
      url: site.url,
      employee: TEAM.map((m) => ({ "@type": "Person", name: m.name, jobTitle: m.role })),
    },
  ],
};

export default function AboutPage() {
  const images = imageAvailability();
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />
      <Header />
      <main id="main">
        <AboutHero />
        <Leadership team={TEAM} images={images} />
        <Governance />
        <AboutCta />
      </main>
      <Footer />
    </>
  );
}
