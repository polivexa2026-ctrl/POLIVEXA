/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // Set NEXT_OUTPUT=export to produce a fully static build in /out
  ...(process.env.NEXT_OUTPUT === "export" ? { output: "export", images: { unoptimized: true } } : {}),
};
export default nextConfig;
